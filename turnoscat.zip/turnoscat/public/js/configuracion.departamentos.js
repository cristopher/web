$(document).ready(function(){
    $("#departamento\\.nuevo").on("click", function(){
        $("#departamento\\.nuevo").addClass("d-none");
        $("#departamento\\.guardar").removeClass("d-none");
        $("#departamento\\.cancelar").removeClass("d-none");
        $("#departamento\\.card").removeClass("d-none");
        $("#departamento\\.nombre").val("");
        $("#departamento\\.jefe").val(0);
        $("#departamento\\.categoria").val(0);
        $("#departamento\\.horas").val(24);
        $("#departamento\\.horas\\.refuerzo").val(24);
        $("#departamento\\.jornada").val(1);
        $("#departamento\\.horas\\.asignadas").val(12);
        $("#departamento\\.horas\\.refuerzo\\.asignadas").val(12);
        $("#departamento\\.comentario").val(0);
        $("#hidden\\.departamento\\.id").val(0);
        $(".departamento-modificar").prop('disabled', true);
        $(".departamento-eliminar").prop('disabled', true);
    });

    $("#departamento\\.guardar").on("click", function(){
        $("#departamento\\.nuevo").removeClass("d-none");
        $("#departamento\\.guardar").addClass("d-none");
        $("#departamento\\.cancelar").addClass("d-none");
        $("#departamento\\.card").addClass("d-none");
        let titular = $("#departamento\\.valor\\.titular").val() > 0 ? $("#departamento\\.valor\\.titular").val() : 0;
        let refuerzo = $("#departamento\\.valor\\.refuerzo").val() > 0 ? $("#departamento\\.valor\\.refuerzo").val() : 0;

        let data = new FormData()

        data.append("accion", "departamentos")
        data.append("nombre", $("#departamento\\.nombre").val())
        data.append("jefe", $("#departamento\\.jefe").val())
        data.append("categoria", $("#departamento\\.categoria").val())
        data.append("hora_turnos", $("#departamento\\.horas").val())
        data.append("hora_refuerzos", $("#departamento\\.horas\\.refuerzo").val())
        data.append("hora_jornada", $("#departamento\\.jornada").val())
        data.append("valor_titular", titular)
        data.append("valor_refuerzo", refuerzo)
        data.append("id", $("#hidden\\.departamento\\.id").val())
        data.append("horas_asignadas", $("#departamento\\.horas\\.asignadas").val())
        data.append("horas_asignadas_refuerzo", $("#departamento\\.horas\\.refuerzo\\.asignadas").val())
        data.append("comentario", $("#departamento\\.comentario").val())
    
        fetch(_api + '/set', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
        .then(data => {
    
            departamentos();
            $("#departamento\\.nombre").val("");
            $("#departamento\\.jefe").val(0);
            $("#departamento\\.categoria").val(0);
            $("#departamento\\.horas").val(24);
            $("#departamento\\.horas\\.refuerzo").val(24);
            $("#departamento\\.jornada").val(1);
            $("#hidden\\.departamento\\.id").val(0);
            $("#departamento\\.horas\\.asignadas").val(12);
            $("#departamento\\.horas\\.refuerzo\\.asignadas").val(12);
            $("#departamento\\.comentario").val(0);
    
        }).catch(function(error) {
            alert("error")
        });
    });

    $("#departamento\\.cancelar").on("click", function(){
        $("#departamento\\.nuevo").removeClass("d-none");
        $("#departamento\\.guardar").addClass("d-none");
        $("#departamento\\.cancelar").addClass("d-none");
        $("#departamento\\.card").addClass("d-none");

        $("#departamento\\.nombre").val("");
        $("#departamento\\.jefe").val(0);
        $("#departamento\\.horas").val(24);
        $("#departamento\\.horas\\.refuerzo").val(24);
        $("#departamento\\.horas\\.asignadas").val(12);
        $("#departamento\\.horas\\.refuerzo\\.asignadas").val(12);
        $("#departamento\\.jornada").val(1);
        $("#departamento\\.categoria").val(0);
        $("#departamento\\.comentario").val(0);
        $("#hidden\\.departamento\\.id").val(0);
        $(".departamento-modificar").prop('disabled', false);
        $(".departamento-eliminar").prop('disabled', false);
    });

    departamentos();
    Jefes();

    $("#hidden\\.departamento\\.id").val(0);
});

function departamentos(){
    let data = new FormData()

    data.append("accion", "departamentos")

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        $("#departamento\\.tabla").empty();
        $("#empleados\\.departamentos").empty().append('<option value="0">Seleccione..</option>');

        var categoria = ['Una columna', 'Dos columnas', 'Cuatro columnas'];

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let table = '<tr><td>' + item.departamento_name + '</td><td>' + categoria[item.departamento_categoria] + '</td><td><button class="btn btn-info departamento-modificar" data-id="'+ item.departamento_id +'">Modificar</button> <button class="btn btn-danger departamento-eliminar" data-id="'+ item.departamento_id +'">Eliminar</button></td></tr>';
                let option =  '<option value="' + item.departamento_id + '">' + item.departamento_name + '</option>';
                $("#departamento\\.tabla").append(table);
                $("#empleados\\.departamentos").append(option);
            });

            $(".departamento-modificar").on("click", function(){
                $(".departamento-modificar").prop('disabled', true);
                $(this).text("Cargando...");

                let data = new FormData()

                data.append("accion", "departamento")
                data.append("departamento", $(this).data("id"))
            
                let presionado = this;

                fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
                .then(data => {
            
                    $(presionado).text("Modificar");
                    $(".departamento-modificar").prop('disabled', false);
                    $("#departamento\\.nuevo").trigger("click");

                    $("#departamento\\.nombre").val(data.departamento_name);
                    $("#departamento\\.jefe").val(data.departamento_jefe);
                    $("#departamento\\.categoria").val(data.departamento_categoria);
                    $("#departamento\\.horas").val(data.departamento_horas_realizadas);
                    $("#departamento\\.horas\\.refuerzo").val(data.departamento_horas_refuerzo);
                    $("#departamento\\.valor\\.titular").val(data.departamento_titular);
                    $("#departamento\\.jornada").val(data.departamento_jornada);
                    $("#departamento\\.valor\\.refuerzo").val(data.departamento_refuerzo);
                    $("#departamento\\.horas\\.asignadas").val(data.departamento_horas_asignadas);
                    $("#departamento\\.horas\\.refuerzo\\.asignadas").val(data.departamento_horas_asignadas_refuerzo);
                    $("#departamento\\.comentario").val(data.departamento_comentarios);
    
                    $("#hidden\\.departamento\\.id").val(data.departamento_id);
            
                }).catch(function(error) {
                    alert("error")
                });
            });
    
            $(".departamento-eliminar").on("click", function(){
                $(".departamento-eliminar").prop('disabled', true);
                $(this).text("Eliminando..");
                let id = $(this).data("id");
                $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="alerta.title">Pregunta</h4><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="modal-body" id="alerta.body">¿Está seguro?</div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
                $("#alerta\\.footer").html('<button id="alerta.eliminar" class="btn btn-secondary" data-id="' + id + '">Eliminar</button><button class="btn btn-danger" id="alerta.cancelar">Cancelar</button>');
                $("#alerta\\.eliminar").on("click", function(){

                    let data = new FormData()

                    data.append("accion", "departamentos")
                    data.append("departamento_id", $(this).data("id"))

                    fetch(_api + '/delete', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
                    .then(data => {

                        departamentos();
                        $("#alerta\\.view").modal("hide").remove();

                    }).catch(function(error) {
                        alert("error")
                    });
                });
                $("#alerta\\.cancelar").on("click", function(){
                    $("#alerta\\.view").modal("hide").remove();
                    $(".departamento-eliminar").prop('disabled', false).text("Eliminar");
                });
                $("#alerta\\.view").modal("show");
            });
        }

    }).catch(function(error) {
        alert("error")
    });
}

function Jefes(){
    let data = new FormData()

    data.append("accion", "jefes")

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        $("#departamento\\.jefe").empty();
        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.user_id + '">' + item.user_name + '</option>';
                $("#departamento\\.jefe").append(option);
            });
        }

    }).catch(function(error) {
        alert("error")
    });
}