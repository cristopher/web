$(document).ready(function(){
    let data = {
        accion : "horas",
        departamento: $("#departamentos\\.header").val(),
        mes: mes,
        ano: año
    }

    $.post(_api + "/get", data).done(function(response){

        if (Object.keys(response).length > 0) {
        }
    });
});