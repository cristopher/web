function departamentos(){
    let data = new FormData()

    data.append("accion", "departamentos")

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        $("#departamentos\\.header").empty();

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.departamento_id + '" data-categoria="' + item.departamento_categoria + '" data-jefe="' + item.departamento_eljefe + '" data-hora-asignada="' + item.departamento_horas_asignadas + '" data-hora-asignada-refuerzo="'+ item.departamento_horas_asignadas_refuerzo+'" data-hora-realizada="' + item.departamento_horas_realizadas + '" data-hora-refuerzo="' + item.departamento_horas_refuerzo + '" data-comentario="' + item.departamento_comentarios + '" data-jornada="'+item.departamento_jornada+'">' + item.departamento_name + '</option>';
                $("#departamentos\\.header").append(option);
            });
            $("#departamentos\\.header").trigger("change");
        }

    }).catch(function(error) {
        alert("error")
    });
}

function profesionales(element, departamento){
    let data = new FormData()

    data.append("accion", "profesionales")
    data.append("departamento", departamento)

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        $(element).empty();

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.profesional_id + '">' + item.user_name + '</option>';
                $(element).append(option);
            });
        }
        else{
            let option = '<option value="0">No hay disponibles</option>';
            $(element).append(option);
        }

    }).catch(function(error) {
        alert("error")
    });
}

function dinero(num){
    if(!isNaN(num)){
        num = num.toString().split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,'$1.');
        num = num.split('').reverse().join('').replace(/^[\.]/,'');
        return num;
    }else{
        return num.replace(/[^\d\.]*/g,'');
    }
}