$(document).ready(function(){

    $("#empleados\\.departamentos").on("change", function(){
        empleados();
        profesionales();
    });

    $("#empleados\\.nuevo").on("click", function(){
        $("#empleados\\.nuevo").addClass("d-none");
        $("#empleados\\.guardar").removeClass("d-none");
        $("#empleados\\.cancelar").removeClass("d-none");
        $("#empleados\\.departamentos").prop("disabled", true);
        $(".empleados-desvincular").prop('disabled', true);
        $("#hidden\\.empleado\\.id").val(0);
        $("#empleados\\.card").removeClass("d-none");
    });
    
    $("#empleados\\.guardar").on("click", function(){
        $("#empleados\\.nuevo").removeClass("d-none");
        $("#empleados\\.guardar").addClass("d-none");
        $("#empleados\\.cancelar").addClass("d-none");
        $("#empleados\\.departamentos").prop("disabled", false);
        $("#empleados\\.card").addClass("d-none");
        $("#empleados\\.profesionales").prop("disabled", false);

        let data = new FormData()
    
        data.append("accion", "profesionales")
        data.append("departamento_id", $("#empleados\\.departamentos").val())
        data.append("profesional_id", $("#empleados\\.profesionales").val())
    
        fetch(_api + '/set', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
        .then(data => {
            
            empleados();
            profesionales();
    
        }).catch(function(error) {
            alert("error")
        });
    });

    $("#empleados\\.cancelar").on("click", function(){
        $("#empleados\\.nuevo").removeClass("d-none");
        $("#empleados\\.guardar").addClass("d-none");
        $("#empleados\\.cancelar").addClass("d-none");
        $("#empleados\\.departamentos").prop("disabled", false);
        $(".empleados-desvincular").prop('disabled', false);
        $("#empleados\\.profesionales").prop("disabled", false);
        $("#hidden\\.empleado\\.id").val(0);
        $("#empleados\\.card").addClass("d-none");
    });

    $("#hidden\\.empleado\\.id").val(0);
});



function empleados(){

    let data = new FormData()
    let departamento = $("#empleados\\.departamentos").val()

    data.append("accion", "profesionales")
    data.append("departamento", departamento)

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {
        
        $("#empleados\\.tabla").empty();

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<tr><td>' + item.user_name + '</td><td>' + item.user_phone + '</td><td>' + item.user_email + '</td><td><button class="btn btn-info empleados-desvincular" data-id="'+ item.profesional_id +'">Desvincular dpto.</button></td></tr>';
                $("#empleados\\.tabla").append(option);
            });
        }

        $(".empleados-desvincular").on("click", function(){
            $(".empleados-desvincular").prop('disabled', true);
            $(this).text("Eliminando..");
            let id = $(this).data("id");
            
            $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="alerta.title">Pregunta</h4><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="modal-body" id="alerta.body">¿Está seguro?</div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
            $("#alerta\\.footer").html('<button id="alerta.eliminar" class="btn btn-secondary" data-id="' + id + '">Eliminar</button><button class="btn btn-danger" id="alerta.cancelar">Cancelar</button>');
            $("#alerta\\.eliminar").on("click", function(){
                let data = new FormData()
                let departamento = $("#empleados\\.departamentos").val()
            
                data.append("accion", "profesionales")
                data.append("departamento_id", departamento)
                data.append("profesional_id", $(this).data("id"))
            
                fetch(_api + '/delete', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
                .then(data => {
                    
                    empleados();
                    profesionales();
                    $("#alerta\\.view").modal("hide").remove();
            
                }).catch(function(error) {
                    alert("error")
                });
            });

            $("#alerta\\.cancelar").on("click", function(){
                $("#alerta\\.view").modal("hide").remove();
                $(".empleados-desvincular").prop('disabled', false).text("Desvincular dpto.");
            });
            $("#alerta\\.view").modal("show");
        });

    }).catch(function(error) {
        alert("error")
    });
}

function profesionales(){

    let data = new FormData()
    let departamento = $("#empleados\\.departamentos").val()

    data.append("accion", "profesionalesAll")
    data.append("departamento", departamento)

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {
        
        $("#empleados\\.profesionales").empty();

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.user_id + '">' + item.user_name + '</option>';
                $("#empleados\\.profesionales").append(option);
            });
        }

    }).catch(function(error) {
        alert("error")
    });

}