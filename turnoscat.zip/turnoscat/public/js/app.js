$(document).ready(function(){
    let now = new Date();
    let month = ("0" + (now.getMonth() + 1)).slice(-2);

    $("#fecha\\.mes").val(month);
    $("#fecha\\.ano").val(now.getFullYear());

    $("#departamentos\\.header").on("change", function(){
        let mes = $("#fecha\\.mes").val();
        let año = $("#fecha\\.ano").val();

        dataCalendar(mes,año);

        var departamento_id = $(this).val();
        var jefe = this.options[this.selectedIndex].dataset.jefe;

        if (+user_category > 2 || jefe == 'true'){
            $("#boton\\.ver\\.esclavos").removeClass("d-none")
            $("#esclavos").attr("href", "index/usuarios/"+ departamento_id);
            $("#boton\\.ver\\.hora").removeClass("d-none")
            $("#boton\\.ver\\.hora").off("click", ver_hora)
            $("#boton\\.ver\\.hora").on("click", ver_hora)
        } else if (+user_category > 2){
            $("#boton\\.ver\\.esclavos").addClass("d-none")
            $("#boton\\.ver\\.hora").removeClass("d-none")
            $("#boton\\.ver\\.hora").off("click", ver_hora)
        }

    });

    $("#fecha\\.mes").on("change", function(){

        let mes = $("#fecha\\.mes").val();
        let año = $("#fecha\\.ano").val();
        dataCalendar(mes,año);

    });

    $("#fecha\\.ano").on("change", function(){

        let mes = $("#fecha\\.mes").val();
        let año = $("#fecha\\.ano").val();
        dataCalendar(mes,año);

    });

    departamentos();
});

function baseCalendar(mes, año){
    let dias = ["Lunes ", "Martes ", "Miércoles ", "Jueves ", "Viernes ", "Sábado ", "Domingo "];
    let _total = new Date(año, (+mes), 0).getDate();
    let _primer = new Date(año, ((+mes)-1), 0).getDay();
    let H = 1;

    let departamento = document.getElementById("departamentos.header")
    let categoria = +departamento.options[departamento.selectedIndex].dataset.categoria;
    let comentario = +departamento.options[departamento.selectedIndex].dataset.comentario;

    if (departamento.options[departamento.selectedIndex].dataset.jornada == 1){
        $("#segunda\\.cabecera\\.tercera\\.columna").html("Turno Diurno");
        $("#segunda\\.cabecera\\.cuarta\\.columna").html("Turno Nocturno");
    } else{
        $("#segunda\\.cabecera\\.tercera\\.columna").html("Turno Mañana");
        $("#segunda\\.cabecera\\.cuarta\\.columna").html("Turno Tarde");
    }

    $("#table\\.calendario").empty();

    for (H; H <= _total; H++){
        let rojo = "";

        if (_primer == 5 || _primer == 6){
            rojo = "text-danger";
        }

        let fila = '<tr><td class="bg-light ' + rojo +'">' + dias[_primer] + " " + H  + "</td></tr>";

        $("#table\\.calendario").append(fila);
        _primer = _primer == 6 ? 0 : _primer + 1 ;
    }

    if (categoria == 1){
        $("#segunda\\.cabecera").removeClass("d-none");
        $("#tercera\\.cabecera").addClass("d-none");
        $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",2);
        $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",2).attr("colspan",1);
        $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",2);
        $("#segunda\\.cabecera\\.tercera\\.columna").attr("colspan",1);
        $("#segunda\\.cabecera\\.cuarta\\.columna").attr("colspan",1);

    } else if (categoria == 2){
        $("#segunda\\.cabecera").removeClass("d-none");
        $("#tercera\\.cabecera").removeClass("d-none");
        $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",3);
        $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",2).attr("colspan",2);
        $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",4);
        $("#segunda\\.cabecera\\.tercera\\.columna").attr("colspan",2);
        $("#segunda\\.cabecera\\.cuarta\\.columna").attr("colspan",2);

    } else{
        $("#segunda\\.cabecera").addClass("d-none");
        $("#tercera\\.cabecera").addClass("d-none");
        $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",1);
        $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",1).attr("colspan",1);
        $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",1);
    }

    if (comentario == 1){
        let colspan = +$("#primera\\.cabecera\\.segunda\\.columna").attr("colspan");
        colspan++;
        $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",colspan).attr("rowspan",1);
        $("#segunda\\.cabecera\\.primera\\.columna").removeClass("d-none");
        $("#segunda\\.cabecera\\.segunda\\.columna").removeClass("d-none");

        if (categoria == 0){
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",2);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("rowspan",2);
            $("#segunda\\.cabecera").removeClass("d-none");
            $("#segunda\\.cabecera\\.tercera\\.columna").addClass("d-none");
            $("#segunda\\.cabecera\\.cuarta\\.columna").addClass("d-none");
        } else if (categoria == 1){
            $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",1);
            $("#segunda\\.cabecera\\.segunda\\.columna").attr("rowspan",1);
        } else if (categoria == 2){
            $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",2);
            $("#segunda\\.cabecera\\.segunda\\.columna").attr("rowspan",2);
        }
    }else{
        $("#segunda\\.cabecera\\.primera\\.columna").addClass("d-none");
        $("#segunda\\.cabecera\\.segunda\\.columna").addClass("d-none");

    }
}

function dataCalendar(mes, año){
    let data = new FormData()
    data.append("accion", "calendario")
    data.append("departamento", $("#departamentos\\.header").val())
    data.append("mes", mes)
    data.append("ano", año)

    baseCalendar(mes,año);

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        let _total = new Date(año, (+mes), 0).getDate();
        let H = 1;
        let departamento = document.getElementById("departamentos.header")

        let categoria = +departamento.options[departamento.selectedIndex].dataset.categoria;
        let comentario = +departamento.options[departamento.selectedIndex].dataset.comentario;

        for (H; H <= _total; H++){
            const fecha = año + "-" + mes + "-" + ("0" + H).slice(-2);

            const turnoDia = filtrarFecha(data, fecha);

            const programadoDia = filtrarProgramados(turnoDia);
            let fila = '';

            fila += crearFilaCalendario(programadoDia, 0, fecha);

            const asignadoRefuerzo = turnoDia.filter(turno => { return turno.turno_categoria === "5"; });
            const comentarios = turnoDia.filter(turno => { return turno.turno_categoria === "6"; });
            const uno = turnoDia.filter(turno => { return turno.turno_categoria === "1"; });
            const dos = turnoDia.filter(turno => { return turno.turno_categoria === "2"; });
            const tres = turnoDia.filter(turno => { return turno.turno_categoria === "3"; });
            const cuatro = turnoDia.filter(turno => { return turno.turno_categoria === "4"; });

            if (categoria == 1){
                if (comentario == 1){
                    fila += crearFilaCalendario(comentarios, 6, fecha);
                }
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
            }
            else if (categoria == 2){
                fila += crearFilaCalendario(asignadoRefuerzo, 5, fecha);
                if (comentario == 1){
                    fila += crearFilaCalendario(comentarios, 6, fecha);
                }
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(dos, 2, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
                fila += crearFilaCalendario(cuatro, 4, fecha);
            }
            else{
                if (comentario == 1){ fila += crearFilaCalendario(comentarios, 6, fecha); }
                fila += crearFilaCalendario(uno, 1, fecha);
            }

            $("#table\\.calendario tr:nth-child(" + H + ")").append(fila);
        }

        $("#table\\.calendario tr td").on("click", function(){
            let fecha = $(this).data("fecha");
            let categoria = $(this).data("categoria");

            if (categoria < 6){
                $("#dialog\\.title").html("Información");
                $("#dialog\\.body").html('<button type="button" class="btn btn-info my-2" id="turno.nuevo">Nuevo Turno</button><div class="card d-none shadow" id="turno.card"><div class="card-body"><h5 class="card-title">Nuevo Turno</h5><input class="form-control" type="hidden" id="hidden.turno.categoria"><input class="form-control" type="hidden" id="hidden.turno.fecha"> <div class="row"><div class="form-group col-6"><label for="turno.profesional">Profesional asignado</label><select class="form-control" id="turno.profesional"><option value="0" selected>Cargando...</option></select></div><div class="form-group col-6"><label for="turno.horas">Horas</label><select class="form-control" id="turno.horas"><option value="1">1 hora</option><option value="2">2 hora</option><option value="3">3 hora</option><option value="4">4 hora</option><option value="5">5 hora</option><option value="6">6 hora</option><option value="7">7 hora</option><option value="8">8 hora</option><option value="9">9 hora</option><option value="10">10 hora</option><option value="11">11 hora</option><option value="12">12 hora</option></select></div></div><div role="group" class="btn-group my-2"><button type="button" class="btn btn-outline-primary d-none" id="turno.guardar">Guardar</button><button type="button" class="btn btn-outline-secondary d-none" id="turno.cancelar">Cancelar</button></div></div></div><table class="table my-2"><thead class="thead-light"><tr><th scope="col">Profesional</th><th scope="col">Horas</th><th scope="col">Acciones</th></tr></thead><tbody id="turno.tabla"></tbody></table>');
                $("#hidden\\.turno\\.fecha").val(fecha);
                $("#hidden\\.turno\\.categoria").val(categoria);
                //determinar cuantas horas hace en esta caja seleccionada
                var horaDepartamento = 0;
                if (categoria == 0){
                    horaDepartamento = +($("#departamentos\\.header option:selected").data("hora-asignada"));
                }else if (categoria == 5){
                    horaDepartamento = +($("#departamentos\\.header option:selected").data("hora-asignada-refuerzo"));
                }else if (categoria == 1 || categoria == 3){
                    horaDepartamento = +($("#departamentos\\.header option:selected").data("hora-realizada"));
                }else if (categoria == 2 || categoria == 4){
                    horaDepartamento = +($("#departamentos\\.header option:selected").data("hora-refuerzo"));
                }
                
                if (horaDepartamento == 24){
                    let H = 1;

                    for (H; H <= 12; H++){
                        $("#turno\\.horas").append('<option value="' + (H + 12) +'">' + (H + 12) + ' hora</option>');
                    }
                    
                    $("#turno\\.horas option:nth-child(24)").prop('selected', true);

                }
                else{
                    $("#turno\\.horas option:nth-child("+horaDepartamento+")").prop('selected', true);
                }

                profesionales("#turno\\.profesional", $("#departamentos\\.header").val());

                $("#turno\\.nuevo").on("click", function(){
                    if (user_category > 2){
                        $("#turno\\.nuevo").addClass("d-none");
                        $("#turno\\.guardar").removeClass("d-none");
                        $("#turno\\.cancelar").removeClass("d-none");
                        $("#turno\\.card").removeClass("d-none");
                        $(".cambiar-turno").prop('disabled', true);
                        $(".modificar-turno").prop('disabled', true);
                        $(".eliminar-turno").prop('disabled', true);
                        $("#dialog\\.body table").addClass("d-none")
                    }else{
                        $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="alerta.title">Advertencia</h4></div><div class="modal-body" id="alerta.body"><h1 class="text-center text-danger">No Autorizado</h1></div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
                        $("#alerta\\.footer").html('<button id="alerta.cerrar" class="btn btn-secondary" >Cerrar</button>');

                        $("#alerta\\.cerrar").on("click", function(){
                            $("#alerta\\.view").modal("hide").remove();
                        });
                        $("#alerta\\.view").modal("show");
                    }
                });

                $("#turno\\.guardar").on("click", function(){
                    if (categoria == 0 || categoria == 5){

                        let _modal = modal("Aceptar");

                        document.getElementsByTagName("body")[0].insertAdjacentHTML( 'beforeend', _modal.modal);
                        the(_modal.titulo).innerHTML = "Copia";
                        the(_modal.titulo).classList.add("mx-auto");
                        the(_modal.titulo).parentElement.classList.add("bg-indigo", "text-white");
                        the(_modal.titulo).parentElement.parentElement.classList.add("border-indigo");
                    
                        let select = uuidv4()
                        let _contenido = '<div class="form-group"><label for="'+select+'">Seleccione modalidad de turno</label><select class="form-control" id="'+select+'"  aria-describedby="seleccionaHelp"><option value="3" selected>Ambos turnos</option><option value="1">Solo turno diurno</option><option value="2">Solo turno nocturno</option><option value="0">Solo turno seleccionado</option></select><small id="seleccionaHelp" class="form-text text-muted">El turno asignado se copiará a turno diurno y/o nocturno</small></div>'
                        the(_modal.button).dataset.select = select;
                        the(_modal.contenido).innerHTML = _contenido;
                        the(_modal.id).children[0].classList.remove("modal-lg");
                    
                        $('#'+_modal.id).modal("show").on('hidden.bs.modal', function (e) { $(this).remove(); });
 
                        $('#'+_modal.button).on("click", function(){
                            $("#turno\\.nuevo").removeClass("d-none");
                            $("#turno\\.guardar").addClass("d-none");
                            $("#turno\\.cancelar").addClass("d-none");
                            $("#turno\\.card").addClass("d-none");
                            $("#"+ this.dataset.modal).modal("hide");
        
                            let body = new FormData()
                            body.append("accion", "turno")
                            body.append("departamento", $("#departamentos\\.header").val())
                            body.append("fecha", $("#hidden\\.turno\\.fecha").val())
                            body.append("categoria", $("#hidden\\.turno\\.categoria").val())
                            body.append("profesional", $("#turno\\.profesional").val())
                            body.append("horas", $("#turno\\.horas").val())
                            body.append("copia", the(this.dataset.select).value)
                
                            fetch(_api + '/set', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                                let mes = $("#fecha\\.mes").val();
                                let año = $("#fecha\\.ano").val();
                                dataCalendar(mes,año);
                                $(".cambiar-turno").prop('disabled', false);
                                $(".modificar-turno").prop('disabled', false);
                                $(".eliminar-turno").prop('disabled', false);
                                $("#dialog\\.body table").removeClass("d-none")
        
                                body = new FormData()
                                body.append("accion", "turno")
                                body.append("departamento", $("#departamentos\\.header").val())
                                body.append("fecha", $("#hidden\\.turno\\.fecha").val())
                                body.append("categoria", $("#hidden\\.turno\\.categoria").val())
            
                                fetch(_api + '/get', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                                    if (Object.keys(data).length > 0) {
                                        tablaTurnos(data);
                                    }
                                })
                            })
                        })
                    }else{
                        $("#turno\\.nuevo").removeClass("d-none");
                        $("#turno\\.guardar").addClass("d-none");
                        $("#turno\\.cancelar").addClass("d-none");
                        $("#turno\\.card").addClass("d-none");

                        let body = new FormData()
                            body.append("accion", "turno")
                            body.append("departamento", $("#departamentos\\.header").val())
                            body.append("fecha", $("#hidden\\.turno\\.fecha").val())
                            body.append("categoria", $("#hidden\\.turno\\.categoria").val())
                            body.append("profesional", $("#turno\\.profesional").val())
                            body.append("horas", $("#turno\\.horas").val())
                            body.append("copia", 0)
                
                            fetch(_api + '/set', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                                let mes = $("#fecha\\.mes").val();
                                let año = $("#fecha\\.ano").val();
                                dataCalendar(mes,año);
                                $(".cambiar-turno").prop('disabled', false);
                                $(".modificar-turno").prop('disabled', false);
                                $(".eliminar-turno").prop('disabled', false);
                                $("#dialog\\.body table").removeClass("d-none")
        
                                body = new FormData()
                                body.append("accion", "turno")
                                body.append("departamento", $("#departamentos\\.header").val())
                                body.append("fecha", $("#hidden\\.turno\\.fecha").val())
                                body.append("categoria", $("#hidden\\.turno\\.categoria").val())
            
                                fetch(_api + '/get', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                                    if (Object.keys(data).length > 0) {
                                        tablaTurnos(data);
                                    }
                                })
                            })
                    }
                });

                $("#turno\\.cancelar").on("click", function(){
                    $("#turno\\.nuevo").removeClass("d-none");
                    $("#turno\\.guardar").addClass("d-none");
                    $("#turno\\.cancelar").addClass("d-none");
                    $("#turno\\.card").addClass("d-none");
                    $(".cambiar-turno").prop('disabled', false);
                    $(".modificar-turno").prop('disabled', false);
                    $(".eliminar-turno").prop('disabled', false);
                    $("#dialog\\.body table").removeClass("d-none")
                });
            } else {
                $("#dialog\\.title").html("Comentario");
                $("#dialog\\.body").html('<div class="card"><div class="card-body"><h5 class="card-title">Comentario (Max 250 carácteres)</h5><input class="form-control" type="hidden" id="hidden.turno.categoria"><input class="form-control" type="hidden" id="hidden.turno.id"><input class="form-control" type="hidden" id="hidden.turno.fecha"> <div class="row"><div class="form-group col-12"><textarea class="form-control" id="comentario.text" rows="3"></textarea></div></div></div></div>');

                $("#dialog\\.footer").prepend('<button type="button" class="btn btn-outline-primary" id="comentario.guardar">Guardar</button><button type="button" class="btn btn-outline-danger" id="comentario.eliminar">Eliminar</button>')

                $("#hidden\\.turno\\.fecha").val(fecha);
                $("#hidden\\.turno\\.categoria").val(categoria);

                $("#comentario\\.guardar").on("click", function(){
                    let body = new FormData()

                    body.append("accion", "comentario")
                    body.append("departamento", $("#departamentos\\.header").val())
                    body.append("fecha", $("#hidden\\.turno\\.fecha").val())
                    body.append("categoria", $("#hidden\\.turno\\.categoria").val())
                    let comentario = $("#comentario\\.text").val()
                    body.append("comentario", comentario.slice(0,250))
                    body.append("turno_id", $("#hidden\\.turno\\.id").val())

                    fetch(_api + '/set', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                        let mes = $("#fecha\\.mes").val();
                        let año = $("#fecha\\.ano").val();
                        dataCalendar(mes,año);
                        $("#comentario\\.guardar").remove()
                        $("#comentario\\.eliminar").remove()
                        $("#dialog\\.view").modal("hide");
                    })
                });

                $("#comentario\\.eliminar").on("click", function(){
                    let id = $("#hidden\\.turno\\.id").val()
                    $(this).text("Eliminando..");
                    $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header bg-danger"><h4 class="modal-title mx-auto text-white" id="alerta.title">Eliminar comentario</h4></div><div class="modal-body text-center" id="alerta.body">¿Está seguro?</div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
                    $("#alerta\\.footer").html('<button id="alerta.eliminar" class="btn btn-secondary" data-id="' + id + '">Eliminar</button><button class="btn btn-danger" id="alerta.cancelar">Cancelar</button>');
                    $("#alerta\\.eliminar").on("click", function(){
                        let body = new FormData()
                        body.append("accion", "turno")
                        body.append("turno_id", id)
            
                        fetch(_api + '/delete', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                            tablaTurnos(data);
                            let mes = $("#fecha\\.mes").val(); let año = $("#fecha\\.ano").val();
                            dataCalendar(mes,año);
                            $("#comentario\\.guardar").remove()
                            $("#comentario\\.eliminar").remove()
                            $("#alerta\\.view").modal("hide").remove();
                            $("#dialog\\.view").modal("hide");
                        })
                    });
        
                    $("#alerta\\.cancelar").on("click", function(){ $("#alerta\\.view").modal("hide").remove(); $("#comentario\\.eliminar").text("Eliminar").prop('disabled', false).text("Eliminar"); });
                    $("#alerta\\.view").modal("show");
                });

                $("#dialog\\.view").modal("show").on('hidden.bs.modal', closeComentario);
            }

            let body = new FormData()
            body.append("accion", "turno")
            body.append("departamento", $("#departamentos\\.header").val())
            body.append("fecha", fecha)
            body.append("categoria", categoria)

            fetch(_api + '/get', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                if (Object.keys(data).length > 0) {
                    if (categoria < 6){
                        tablaTurnos(data);
                    }
                    else{
                        document.getElementById("comentario.text").value = data[0].turno_comentario
                        $("#hidden\\.turno\\.id").val(data[0].turno_id)
                    }

                    $("#dialog\\.view").modal("show");
                }else if (user_category > 2){
                    $("#dialog\\.view").modal("show");
                }
            })
        });
    });
}

function crearFilaCalendario(data, tipo, fecha){
    var clase = "";
    var fila = "";
    if (tipo == 0 || tipo == 1 || tipo == 3){
        clase = "bg-light";
    }

    if (data.length > 0 && tipo != 6){
        let a = 0;
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'">';
        for (a; a < data.length; a++){
            let color = data[a].turno_profesional == user_id ? ' text-danger': '';
            fila += '<p class="mb-0' +  color + '">' + data[a].user_name +' <span class="badge badge-pill badge-dark">' + data[a].turno_horas +' hrs.</span></p>';
        }
        fila += '</td>';
    }
    else if (data.length > 0 && tipo == 6){
        let a = 0;
        fila += '<td class="comentario '+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'">';
        for (a; a < data.length; a++){

            let coment = (data[a].turno_comentario.length > 0) ? data[a].turno_comentario.replace(/(?:\r\n|\r|\n)/g, '<br>') : data[a].turno_comentario;
            
            fila += '<p class="mb-0">' + coment +' </p>';
        }
        fila += '</td>';
    }
    else{
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'"></td>';
    }

    return fila;
}

function tablaTurnos(data){
    $("#turno\\.tabla").empty();
    if (Object.keys(data).length > 0) {
        $.each(data, function(i,value){

            let fila = '<tr><td>' + value.user_name + '</td><td>' + value.turno_horas + '</td><td><button class="btn btn-outline-primary ';
            if (user_category == 2){
                fila += 'cambiar-turno" data-id="'+ value.turno_id+'">Cambiar turno</button></td></tr>';    
            }
            else{
                fila += 'modificar-turno mr-1" data-id="'+ value.turno_id+'">Modificar</button><button class="btn btn-outline-danger eliminar-turno" data-id="'+ value.turno_id+'">Eliminar</button></td></tr>';
            }

            $("#turno\\.tabla").append(fila);
        });

        $(".modificar-turno").on("click", function(){
            let id = $(this).data("id");
            $(this).text("Modificar..");
            $(".modificar-turno").prop('disabled', true);

            if (user_category > 2){
                $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"> <div class="modal-dialog" role="document"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title" id="alerta.title">Modificar turno</h4></div><div class="modal-body" id="alerta.body"><div class="row"> <div class="form-group col-12"> <label for="turno.horas.modificar">Horas</label> <select class="form-control" id="turno.horas.modificar"> <option value="1">1 hora</option> <option value="2">2 hora</option> <option value="3">3 hora</option> <option value="4">4 hora</option> <option value="5">5 hora</option> <option value="6">6 hora</option> <option value="7">7 hora</option> <option value="8">8 hora</option> <option value="9">9 hora</option> <option value="10">10 hora</option> <option value="11">11 hora</option> <option value="12">12 hora</option><option value="13">13 hora</option><option value="14">14 hora</option><option value="15">15 hora</option><option value="16">16 hora</option><option value="17">17 hora</option><option value="18">18 hora</option><option value="19">19 hora</option><option value="20">20 hora</option><option value="21">21 hora</option><option value="22">22 hora</option><option value="23">23 hora</option><option value="24">24 hora</option> </select> </div></div></div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
                $("#alerta\\.footer").html('<button id="alerta.guardar" class="btn btn-primary" data-id="'+id+'">Guardar</button><button id="alerta.cerrar" class="btn btn-secondary" >Cerrar</button>');

                $("#alerta\\.guardar").on("click", function(){
                    let id = $(this).data("id");
                    let body = new FormData()
                    body.append("accion", "actualizar")
                    body.append("turno_id", id)
                    body.append("turno_horas", $("#turno\\.horas\\.modificar").val())
        
                    fetch(_api + '/set', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                        let mes = $("#fecha\\.mes").val(); let año = $("#fecha\\.ano").val();
                        dataCalendar(mes,año);
                        $("#alerta\\.view").modal("hide").remove(); $("#dialog\\.view").modal("hide");
                    })
                });

                $("#alerta\\.cerrar").on("click", function(){$(".modificar-turno").text("Modificar").prop('disabled', false); $("#alerta\\.view").modal("hide").remove();});
                $("#alerta\\.view").modal("show");
            } else {
                $(".modificar-turno").prop('disabled', false);
                $(this).text("Modificar");
                $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="alerta.title">Advertencia</h4></div><div class="modal-body" id="alerta.body"><h1 class="text-center text-danger">No Autorizado</h1></div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
                $("#alerta\\.footer").html('<button id="alerta.cerrar" class="btn btn-secondary" >Cerrar</button>');
                $("#alerta\\.cerrar").on("click", function(){ $("#alerta\\.view").modal("hide").remove(); });
                $("#alerta\\.view").modal("show");
            }
        });

        $(".eliminar-turno").on("click", function(){
            let id = $(this).data("id");
            $(this).text("Eliminando..");
            $(".eliminar-turno").prop('disabled', true);
            $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header bg-danger"><h4 class="modal-title mx-auto text-white" id="alerta.title">Eliminar turno</h4></div><div class="modal-body text-center" id="alerta.body">¿Está seguro?</div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
            $("#alerta\\.footer").html('<button id="alerta.eliminar" class="btn btn-secondary" data-id="' + id + '">Eliminar</button><button class="btn btn-danger" id="alerta.cancelar">Cancelar</button>');
            $("#alerta\\.eliminar").on("click", function(){
                let body = new FormData()
                body.append("accion", "turno")
                body.append("turno_id", id)
    
                fetch(_api + '/delete', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                    tablaTurnos(data);
                    let mes = $("#fecha\\.mes").val(); let año = $("#fecha\\.ano").val();
                    dataCalendar(mes,año);
                    $("#alerta\\.view").modal("hide").remove();

                    body = new FormData()
                    body.append("accion", "turno")
                    body.append("departamento", $("#departamentos\\.header").val())
                    body.append("fecha", $("#hidden\\.turno\\.fecha").val())
                    body.append("categoria", $("#hidden\\.turno\\.categoria").val())

                    fetch(_api + '/get', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                        if (Object.keys(data).length > 0) {
                            tablaTurnos(data);
                        }
                    })
                })
            });

            $("#alerta\\.cancelar").on("click", function(){ $("#alerta\\.view").modal("hide").remove(); $(".eliminar-turno").text("Eliminar").prop('disabled', false).text("Eliminar"); });
            $("#alerta\\.view").modal("show");
        });

        $(".cambiar-turno").on("click", function(){
            let id = $(this).data("id");
            $(this).text("Cambiando..");
            $(".cambiar-turno").prop('disabled', true);
            $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="alerta.title">Cambiar turno</h4></div><div class="modal-body" id="alerta.body"><div class="form-group col-6"><label for="turno.profesional.cambiar">Profesional elegido</label><select class="form-control" id="turno.profesional.cambiar"></select></div></div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
            $("#alerta\\.footer").html('<button id="alerta.cambiar" class="btn btn-secondary" data-id="' + id + '">Cambiar</button><button class="btn btn-danger" id="alerta.cancelar">Cancelar</button>');
            var options = $("#turno\\.profesional > option").clone();
            $("#turno\\.profesional\\.cambiar").append(options);
            $("#alerta\\.cambiar").on("click", function(){

                body = new FormData()
                body.append("accion", "cambiar")
                body.append("turno_id", id)
                body.append("turno_profesional", $("#turno\\.profesional\\.cambiar").val())

                fetch(_api + '/set', {method: 'POST',body: body, mode: 'cors'}).then(response => response.json()).then(data => {
                    let mes = $("#fecha\\.mes").val();
                    let año = $("#fecha\\.ano").val();
                    dataCalendar(mes,año);
                    $("#alerta\\.view").modal("hide").remove();
                    $("#dialog\\.view").modal("hide");
                })
            });
            $("#alerta\\.cancelar").on("click", function(){ $("#alerta\\.view").modal("hide").remove(); $(".cambiar-turno").prop('disabled', false).text("Cambiar"); });
            $("#alerta\\.view").modal("show");
        });
    }
}

function ver_hora(){

    let fecha_uno = uuidv4();
    let fecha_dos = uuidv4();

    $("#dialog\\.title").html("Horas Trabajadas en el mes actual");
    $("#dialog\\.body").html('<div class="form-group"> <label for="profe.departamento">Seleccione un profesional</label> <select class="form-control" id="profe.departamento"></select></div><div class="row"><div class="col"><input class="form-control" type="date" id="'+ fecha_uno +'" /></div><div class="col"><input class="form-control" type="date" id="'+ fecha_dos +'" /></div></div><table class="table"> <thead class="thead-dark"> <tr> <th scope="col">Fecha</th> <th scope="col">Titular</th> <th scope="col">Refuerzo</th> <th scope="col">Valor</th> </tr></thead> <tbody id="hora.body.tb"></tbody></table>');
    $("#dialog\\.footer").html('<button class="btn btn-secondary" data-dismiss="modal">Cerrar</button>');
    $("#dialog\\.view").modal("show");

    let mes = $("#fecha\\.mes").val();
    let año = $("#fecha\\.ano").val();

    let _total = new Date(año, (+mes), 0).getDate();

    the(fecha_uno).value = año + "-" + mes + "-01"
    the(fecha_uno).onchange = function(){
        $("#profe\\.departamento").trigger("change")
    }
    the(fecha_dos).value = año + "-" + mes + "-" +_total
    the(fecha_dos).onchange = function(){
        $("#profe\\.departamento").trigger("change")
    }

    let data = new FormData()
    data.append("accion", "profesionales_con_turno")
    data.append("departamento", $("#departamentos\\.header").val())
    data.append("fecha_inicial", the(fecha_uno).value)
    data.append("fecha_final", the(fecha_dos).value)

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        if (Object.keys(data).length > 0) {
            $("#profe\\.departamento").empty();
            $.each(data, function(i, item) {
                let option = '<option value="' + item.profesional_id + '">' + item.user_name + '</option>';
                $("#profe\\.departamento").append(option);
            });
            $("#profe\\.departamento").trigger("change");
        }

    }).catch(function(error) {

        alert("error")

    });

    the("profe.departamento").dataset.fecha_uno = fecha_uno
    the("profe.departamento").dataset.fecha_dos = fecha_dos

    $("#profe\\.departamento").on("change", function(){
        let profesional = $("#profe\\.departamento").val();

        let data = new FormData()
        data.append("accion", "hpersonasrange")
        data.append("departamento", $("#departamentos\\.header").val())
        data.append("fecha_uno", the(this.dataset.fecha_uno).value)
        data.append("fecha_dos", the(this.dataset.fecha_dos).value)
        data.append("profesional", profesional)

        fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
        .then(data => {

            $("#hora\\.body\\.tb").html("");

            if (Object.keys(data).length > 0) {

                let h_titular = 0
                let h_refuerzo = 0
                let _total = 0

                $.each(data.titular, function(i, item) {

                    let suma = +item.turno_horas * +item.departamento_titular
                    $("#hora\\.body\\.tb").append("<tr><td>" + humanDate(toDate(item.turno_fecha)) + "</td><td>" + item.turno_horas + " horas</td><td></td><td> $" + dinero(suma) + "</td></tr>")
                    h_titular += +item.turno_horas
                    _total += suma

                });

                $.each(data.refuerzo, function(i, item) {

                    let suma = +item.turno_horas * +item.departamento_refuerzo
                    $("#hora\\.body\\.tb").append("<tr><td>" + humanDate(toDate(item.turno_fecha)) + "</td><td></td><td>" + item.turno_horas + " horas</td><td> $" + dinero(suma) + "</td></tr>")
                    h_refuerzo += +item.turno_horas
                    _total += suma

                });

                $("#hora\\.body\\.tb").append("<tr><td>Total</td><td>" + h_titular + " horas</td><td>" + h_refuerzo + " horas</td><td> $" + dinero(_total) + "</td></tr>")
            }

        }).catch(function(error) {
            alert("error")
        });
    });
}

function filtrarTurnos(data, nombre){
    let filtro = data.filter(turno => {
        return turno.user_name === nombre;
    });

    return filtro;
}

function filtrarFecha(data, fecha){
    let filtro = data.filter(turno => {
        return turno.turno_fecha === fecha;
    });

    return filtro;
}

function filtrarProgramados(data){
    let filtro = data.filter(turno => {
        return turno.turno_categoria === "0";
    });

    return filtro;
}

function modal(button){
    let id = uuidv4();
    let titulo = uuidv4();
    let contenido = uuidv4();
    let _button = uuidv4();
    let button_string = "";
    
    if (typeof button !== typeof undefined){
        button_string = '<button type="button" class="btn btn-primary" id="'+_button+'" data-modal="'+id+'">'+button+'</button>';
    }
    
    let resultado ={
        id:id,
        titulo:titulo,
        contenido:contenido,
        button:_button,
        modal:'<div class="modal fade" tabindex="-1" role="dialog" id="'+id+'"><div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="'+titulo+'">Modal title</h5></div><div class="modal-body" id="'+contenido+'"></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal" id="cancelarmodal">Cancelar</button>'+ button_string+'</div></div></div></div>'
    }
        
    return resultado;
}

function uuidv4() {
    //genera un uuid
    let uid = ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
        (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    )

    // genera infinitamente uuid mientras no comience con una letra
    if (isNaN(uid.charAt(0))){
        return uid
    }else{
        return uuidv4()
    }
}

function the(id){
    return document.getElementById(id);
}

function closeComentario(){
    $("#comentario\\.guardar").remove()
    $("#comentario\\.eliminar").remove()
    $("#dialog\\.view").off('hidden.bs.modal',closeComentario);
}

function humanDate(date) {
    if (typeof date === typeof undefined){
        date = new Date();
    }
    var dd = date.getDate();
    var mm = date.getMonth()+1; //January is 0!
    var yyyy = date.getFullYear();
  
    if(dd<10) { dd = '0'+dd } 
  
    if(mm<10) {
        mm = '0'+mm
    } 
  
    return dd+ '-' + mm + '-' + yyyy;
}

function toDate(fecha){
    let date = new Date();

    date.setTime(Date.parse(fecha))
    let n = 1000 *60* date.getTimezoneOffset();
    date.setTime(date.getTime() + n)

    return date
}