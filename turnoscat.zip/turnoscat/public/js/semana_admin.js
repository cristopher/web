var fecha_inicial = new Date();
let month_inicial = ("0" + (fecha_inicial.getUTCMonth() + 1)).slice(-2);
let day_inicial = ("0" + (fecha_inicial.getUTCDate())).slice(-2);

var fecha_final = addDays(fecha_inicial, 6);
let month_final = ("0" + (fecha_final.getUTCMonth() + 1)).slice(-2);
let day_final = ("0" + (fecha_final.getUTCDate())).slice(-2);

document.getElementById("fecha.inicial").value = fecha_inicial.getFullYear() + "-" + month_inicial + "-" + day_inicial;
document.getElementById("fecha.final").value = fecha_final.getFullYear() + "-" + month_final + "-" + day_final;

$(document).ready(function(){
    departamentos();

    $("#departamento").on("change", function(){
        turnos_dia(this.value)

        if (this.options[this.selectedIndex].dataset.jornada == 1){
            $("#segunda\\.cabecera\\.primera\\.columna").html("Turno Diurno");
            $("#segunda\\.cabecera\\.segunda\\.columna").html("Turno Nocturno");
        } else{
            $("#segunda\\.cabecera\\.primera\\.columna").html("Turno Mañana");
            $("#segunda\\.cabecera\\.segunda\\.columna").html("Turno Tarde");
        }

        if (this.options[this.selectedIndex].dataset.categoria == 1){
            $("#segunda\\.cabecera").removeClass("d-none");
            $("#tercera\\.cabecera").addClass("d-none");
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",2);
            $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",2).attr("colspan",1);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",2);
            $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",1);
            $("#segunda\\.cabecera\\.segunda\\.columna").attr("colspan",1);
        } else if (this.options[this.selectedIndex].dataset.categoria == 2){
            $("#segunda\\.cabecera").removeClass("d-none");
            $("#tercera\\.cabecera").removeClass("d-none");
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",3);
            $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",2).attr("colspan",2);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",4);
            $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",2);
            $("#segunda\\.cabecera\\.segunda\\.columna").attr("colspan",2);
        } else{
            $("#segunda\\.cabecera").addClass("d-none");
            $("#tercera\\.cabecera").addClass("d-none");
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",1);
            $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",1).attr("colspan",1);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",1);
        }
    });

    $("#fecha\\.inicial").on("change", function(){
        fecha_inicial = new Date(Date.parse(document.getElementById("fecha.inicial").value));
        fecha_final = addDays(fecha_inicial, 6);

        let month_final = ("0" + (fecha_final.getUTCMonth() + 1)).slice(-2);
        let day_final = ("0" + (fecha_final.getUTCDate())).slice(-2);
        document.getElementById("fecha.final").value = fecha_final.getFullYear() + "-" + month_final + "-" + day_final;

        turnos_dia($("#departamento").val())
    });

    $("#fecha\\.final").on("change", function(){
        fecha_final = new Date(Date.parse(document.getElementById("fecha.final").value));
        fecha_inicial = addDays(fecha_final, -6);

        let month_inicial = ("0" + (fecha_inicial.getUTCMonth() + 1)).slice(-2);
        let day_inicial = ("0" + (fecha_inicial.getUTCDate())).slice(-2);
        document.getElementById("fecha.inicial").value = fecha_inicial.getFullYear() + "-" + month_inicial + "-" + day_inicial;

        turnos_dia($("#departamento").val())
    });
});

function filtrarDia(data, fecha){
    let filtro = data.filter(turno => { return turno.turno_fecha === fecha; }); return filtro;
}

function filtrarProgramados(data){
    let filtro = data.filter(turno => { return turno.turno_categoria === "0"; }); return filtro;
}

function crearFilaCalendario(data, tipo, fecha){
    var clase = "";
    var fila = "";
    if (tipo == 1 || tipo == 3){
        clase = "bg-light";
    }

    if (data.length > 0){
        let a = 0;
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'">';
        for (a; a < data.length; a++){
            fila += '<p class="mb-0">' + data[a].user_name +' <span class="badge badge-pill badge-dark">' + data[a].turno_horas +' hrs.</span></p>';
        }
        fila += '</td>';
    } else{
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'"></td>';
    }
    return fila;
}

function baseCalendar(){
    var cuantosDiasMes = new Date(fecha_inicial.getFullYear(), (fecha_inicial.getMonth()+1), 0).getUTCDate();
    let dias = ["Domingo ","Lunes ", "Martes ", "Miércoles ", "Jueves ", "Viernes ", "Sábado "];
    let _total = fecha_inicial.getUTCDate() + 6;
    let _primer = fecha_inicial.getUTCDay();
    let _dia = fecha_inicial.getUTCDate();

    $("#table\\.calendario").empty();

    for (_dia; _dia <= _total; _dia++){
        let internal_dia = _dia;

        if (_dia > cuantosDiasMes){
            _dia = (_dia - cuantosDiasMes);
        }
        let rojo = "";
        if (_primer == 0 || _primer == 6){
            rojo = "text-danger";
        }
        let fila = '<tr><td class="bg-light ' + rojo +'">' + dias[_primer] + " " + _dia + "</td></tr>";

        $("#table\\.calendario").append(fila);
        _primer = _primer == 6 ? 0 : _primer + 1 ;
        _dia = internal_dia;
    }
}

function departamentos(){
    let data = new FormData()

    data.append("accion", "departamentos")

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.departamento_id + '" data-categoria="' + item.departamento_categoria + '" data-jefe="' + item.departamento_eljefe + '" data-hora-asignada="' + item.departamento_horas_asignadas + '" data-hora-realizada="' + item.departamento_horas_realizadas + '" data-hora-refuerzo="' + item.departamento_horas_refuerzo + '" data-jornada="'+item.departamento_jornada+'">' + item.departamento_name + '</option>';
                $("#departamento").append(option);
            });
            $("#departamento").trigger("change");
        }
    }).catch(function(error) {
        alert("error")
    });
}

function turnos_dia(departamento){
    let data = new FormData()

    data.append("accion", "turno_filter")
    data.append("departamento", departamento)
    data.append("fecha_inicial", document.getElementById("fecha.inicial").value)
    data.append("fecha_final", document.getElementById("fecha.final").value)

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        baseCalendar();

        var categoria = $("#departamento option:selected").data("categoria");
        var fecha_inicial = new Date(document.getElementById("fecha.inicial").value);
        fecha_inicial.setDate(fecha_inicial.getDate() - 1);

        for (let i = 0; i <= 6; i++){
            fecha_inicial.setDate(fecha_inicial.getDate() + 1);

            let dia = ("0" + fecha_inicial.getUTCDate()).slice(-2);
            let mes = ("0" + (fecha_inicial.getUTCMonth()+1)).slice(-2);
            let año = fecha_inicial.getUTCFullYear();

            let fecha = año + "-" + mes + "-" + dia;

            const turnoDia = filtrarDia(data, fecha);
            const programadoDia = filtrarProgramados(turnoDia);
            let fila = '';

            fila += crearFilaCalendario(programadoDia, 0, fecha);

            const asignadoRefuerzo = turnoDia.filter(turno => { return turno.turno_categoria === "5"; });
            const uno = turnoDia.filter(turno => { return turno.turno_categoria === "1"; });
            const dos = turnoDia.filter(turno => { return turno.turno_categoria === "2"; });
            const tres = turnoDia.filter(turno => { return turno.turno_categoria === "3"; });
            const cuatro = turnoDia.filter(turno => { return turno.turno_categoria === "4"; });

            if (categoria == 1){
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
            } else if (categoria == 2){
                fila += crearFilaCalendario(asignadoRefuerzo, 5, fecha);
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(dos, 2, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
                fila += crearFilaCalendario(cuatro, 4, fecha);
            } else {
                fila += crearFilaCalendario(uno, 1, fecha);
            }

            $("#table\\.calendario tr:nth-child(" + (i+1) + ")").append(fila);

        }


        //var _año = fecha_inicial.getFullYear();
        //var _mes = (fecha_inicial.getUTCMonth()+1);
        //var cuantosDiasMes = new Date(_año, _mes, 0).getUTCDate();
        //let _total = fecha_inicial.getUTCDate() + 7;
        //let _dia = fecha_inicial.getUTCDate();                
        //var mesCambiado = false;

        //let categoria = $("#departamento option:selected").data("categoria");
        //let contador = 1;

        //for (_dia; _dia <= _total; _dia++){
        //    let internal_dia = _dia;

        //    if (_dia > cuantosDiasMes){
        //        _dia = (_dia - cuantosDiasMes);
        //        if (mesCambiado == false){
        //            _mes++;
        //            mesCambiado = true;
        //            if (_mes == 13){
        //                _año++;
        //                _mes--;
        //            }
        //        }
        //    }

        //    const fecha = _año + "-" + ("0" + _mes).slice(-2) + "-" + ("0" + _dia).slice(-2);
        //    const turnoDia = filtrarDia(data, fecha);
        //    const programadoDia = filtrarProgramados(turnoDia);
        //    let fila = '';

        //    fila += crearFilaCalendario(programadoDia, 0, fecha);

        //    const asignadoRefuerzo = turnoDia.filter(turno => { return turno.turno_categoria === "5"; });
        //    const uno = turnoDia.filter(turno => { return turno.turno_categoria === "1"; });
        //    const dos = turnoDia.filter(turno => { return turno.turno_categoria === "2"; });
        //    const tres = turnoDia.filter(turno => { return turno.turno_categoria === "3"; });
        //    const cuatro = turnoDia.filter(turno => { return turno.turno_categoria === "4"; });

        //    if (categoria == 1){
        //        fila += crearFilaCalendario(uno, 1, fecha);
        //        fila += crearFilaCalendario(tres, 3, fecha);
        //    } else if (categoria == 2){
        //        fila += crearFilaCalendario(asignadoRefuerzo, 5, fecha);
        //        fila += crearFilaCalendario(uno, 1, fecha);
        //        fila += crearFilaCalendario(dos, 2, fecha);
        //        fila += crearFilaCalendario(tres, 3, fecha);
        //        fila += crearFilaCalendario(cuatro, 4, fecha);
        //    } else {
        //        fila += crearFilaCalendario(uno, 1, fecha);
        //    }

        //    $("#table\\.calendario tr:nth-child(" + contador + ")").append(fila);
        //    contador++;
        //    _dia = internal_dia;
        //}
    }).catch(function(error) {
        alert("error")
    });
}

function addDays(date,days){
    var date = new Date(date.valueOf())
    date.setDate(date.getDate() + days)
    return date
}