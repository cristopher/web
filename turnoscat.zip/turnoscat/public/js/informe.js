$(document).ready(function(){
    let fecha = new Date();
    let meses = ["Enero","Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    $("#fecha").html(fecha.getDate() + "-" + meses[fecha.getMonth()] + "-" + fecha.getFullYear());
    $("#meses").html(meses[(+month)-1]);
    dataCalendar(month, year, departament);
});

function baseCalendar(mes, año){

    let dias = ["Lunes ", "Martes ", "Miércoles ", "Jueves ", "Viernes ", "Sábado ", "Domingo "];
    let _total = new Date(año, (+mes), 0).getDate();
    let _primer = new Date(año, ((+mes)-1), 0).getDay();
    let H = 1;
    
    $("#table\\.calendario").empty();

    for (H; H <= _total; H++){
        let rojo = "";

        if (_primer == 5 || _primer == 6){
            rojo = "text-danger";
        }

        let fila = '<tr><td class="bg-light ' + rojo +'">' + dias[_primer] + " " + H  + "</td></tr>";

        $("#table\\.calendario").append(fila);
        _primer = _primer == 6 ? 0 : _primer + 1 ;
    }

    let categoria = +category;

    if (categoria == 1){
        $("#segunda\\.cabecera").removeClass("d-none");
        $("#tercera\\.cabecera").addClass("d-none");
        $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",2);
        $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",2);
        $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",2);
        $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",1);
        $("#segunda\\.cabecera\\.segunda\\.columna").attr("colspan",1);
    }
    else if (categoria == 2){
        $("#segunda\\.cabecera").removeClass("d-none");
        $("#tercera\\.cabecera").removeClass("d-none");
        $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",3);
        $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",3);
        $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",4);
        $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",2);
        $("#segunda\\.cabecera\\.segunda\\.columna").attr("colspan",2);
    }
    else{
        $("#segunda\\.cabecera").addClass("d-none");
        $("#tercera\\.cabecera").addClass("d-none");
        $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",1);
        $("#primera\\.cabecera\\.segunda\\.columna").attr("rowspan",1);
        $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",1);
    }
}

function dataCalendar(mes, año,departament){
    let data = {
        accion : "calendario",
        departamento: departament,
        mes: mes,
        ano: año
    }

    baseCalendar(mes,año);

    $.post(_api + "/get", data).done(function(response){
        let _total = new Date(año, (+mes), 0).getDate();
        let H = 1;
        let categoria = category;
    
        for (H; H <= _total; H++){
            const fecha = año + "-" + mes + "-" + ("0" + H).slice(-2);

            const turnoDia = filtrarDia(response, fecha);

            const programadoDia = filtrarProgramados(turnoDia);
            let fila = '';

            fila += crearFilaCalendario(programadoDia, 0, fecha);

            const uno = turnoDia.filter(turno => {
                return turno.turno_categoria === "1";
            });

            const dos = turnoDia.filter(turno => {
                return turno.turno_categoria === "2";
            });

            const tres = turnoDia.filter(turno => {
                return turno.turno_categoria === "3";
            });

            const cuatro = turnoDia.filter(turno => {
                return turno.turno_categoria === "4";
            });

            if (categoria == 1){
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
            }
            else if (categoria == 2){
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(dos, 2, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
                fila += crearFilaCalendario(cuatro, 4, fecha);
            }
            else{
                fila += crearFilaCalendario(uno, 1, fecha);
            }

            $("#table\\.calendario tr:nth-child(" + H + ")").append(fila);
        }

        let data = {
            accion: "departamento",
            departamento: departament,
        }
    
        $.post(_api + "/get", data).done(function(response){
    
            if (response.departamento_jornada == 1){
                $("#segunda\\.cabecera\\.primera\\.columna").html("Turno Diurno");
                $("#segunda\\.cabecera\\.segunda\\.columna").html("Turno Nocturno");
            }
            else{
                $("#segunda\\.cabecera\\.primera\\.columna").html("Turno Mañana");
                $("#segunda\\.cabecera\\.segunda\\.columna").html("Turno Tarde");
            }
            var ventimp = window;
            ventimp.print();
            ventimp.close();
        });
        
    });
}

function filtrarDia(data, fecha){

    let filtro = data.filter(turno => {
        return turno.turno_fecha === fecha;
    });

    return filtro;
}

function filtrarProgramados(data){
    
    let filtro = data.filter(turno => {
        return turno.turno_categoria === "0";
    });

    return filtro;
}

function crearFilaCalendario(data, tipo, fecha){
    var clase = "";
    var fila = "";
    if (tipo == 1 || tipo == 3){
        clase = "bg-light";
    }

    if (data.length > 0){
        let a = 0;
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'">';
        for (a; a < data.length; a++){
            let color = data[a].turno_profesional == user_id ? ' text-danger': '';
            fila += '<p class="mb-0' +  color + '">' + data[a].user_nombre +' <span class="badge badge-pill badge-dark">' + data[a].turno_horas +' hrs.</span></p>';
        }
        fila += '</td>';
    }
    else{
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'"></td>';
    }

    return fila;
}