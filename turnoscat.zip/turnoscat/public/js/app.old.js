$(document).ready(function(){
    let now = new Date();
    let month = ("0" + (now.getMonth() + 1)).slice(-2);

    $("#fecha\\.mes").val(month);

    $("#departamentos\\.header").on("change", function(){
        let mes = $("#fecha\\.mes").val();
        let año = $("#fecha\\.ano").val();
        dataCalendar(mes,año);
    });

    $("#fecha\\.mes").on("change", function(){
        let mes = $("#fecha\\.mes").val();
        let año = $("#fecha\\.ano").val();
        dataCalendar(mes,año);
    });

    $("#fecha\\.ano").on("change", function(){
        let mes = $("#fecha\\.mes").val();
        let año = $("#fecha\\.ano").val();
        dataCalendar(mes,año);
    });

    departamentos();

    $("#informe\\.mensual").on("click", function(){
        $("#dialog\\.title").html("Generar Informe");
        $("#dialog\\.body").html('<div class="form-row"><div class="col-12 col-sm-4"><div class="form-group"><label for="informe.grupo">Selecciones Grupo del Profesional asignado</label><select id="informe.grupo" class="form-control"><option value="1">Titular</option><option value="0">Refuerzo</option></select></div></div></div>');
        $("#dialog\\.footer").html('').html('<button type="button" class="btn btn-primary" id="informe.imprimir">Ver impresión</button>');
        $("#dialog\\.view").modal("show");
        $("#informe\\.imprimir").on("click", function(){
            window.open("index/informe/" + $("#fecha\\.mes").val() + "/" + $("#fecha\\.ano").val() + "/" + $("#informe\\.grupo").val() + "/" + $("#departamentos\\.header").val(),'_blank');
        });
    });

    $("#informe\\.columna").on("click", function(){
        $("#dialog\\.title").html("Generar Informe");
        $("#dialog\\.body").html('<div class="form-row"><div class="col-12 col-sm-4"><div class="form-group"><label for="informe.grupo">Selecciones Columna</label><select id="informe.grupo" class="form-control"><option value="0">Médico Titular</option><option value="1">Médico de refuerzo</option></select></div></div></div>');
        $("#dialog\\.footer").html('').html('<button type="button" class="btn btn-primary" id="informe.imprimir">Ver impresión</button>');
        $("#dialog\\.view").modal("show");
        $("#informe\\.imprimir").on("click", function(){
            window.open("index/columnas/" + $("#fecha\\.mes").val() + "/" + $("#fecha\\.ano").val() + "/" + $("#informe\\.grupo").val() + "/" + $("#departamentos\\.header").val(),'_blank');
        });
    });
});

function baseCalendar(mes, año){

    let dias = ["Lunes ", "Martes ", "Miércoles ", "Jueves ", "Viernes ", "Sábado ", "Domingo "];
    let _total = new Date(año, (+mes), 0).getDate();
    let _primer = new Date(año, ((+mes)-1), 0).getDay();
    let H = 1;

    $("#table\\.calendario").empty();

    for (H; H <= _total; H++){
        let rojo = "";

        if (_primer == 5 || _primer == 6){
            rojo = "text-danger";
        }

        let fila = '<tr><td class="bg-light ' + rojo +'">' + dias[_primer] + " " + H  + "</td></tr>";

        $("#table\\.calendario").append(fila);
        _primer = _primer == 6 ? 0 : _primer + 1 ;
    }
}

function departamentos(){
    let data = {
        accion : "departamentos"
    }

    $.post(_api + "/get", data).done(function(response){
        $("#departamentos\\.header").empty();

        if (Object.keys(response).length > 0) {
            $.each(response, function(i, item) {
                let option = '<option value="' + item.departamento_id + '" data-reemplazante="' + item.departamento_reemplazante + '">' + item.departamento_name + '</option>';
                $("#departamentos\\.header").append(option);
            });
            $("#departamentos\\.header").trigger("change");
        }
    });
}

function profesionales(element, departamento, grupo){
    let data = {
        accion : "profesionales",
        departamento: departamento,
        grupo: grupo
    }

    $.post(_api + "/get", data).done(function(response){
        $(element).empty();

        if (Object.keys(response).length > 0) {
            $.each(response, function(i, item) {
                let option = '<option value="' + item.profesional_id + '">' + item.user_nombre + '</option>';
                $(element).append(option);
            });
        }
        else{
            let option = '<option value="0">No hay disponibles</option>';
            $(element).append(option);
        }
    });
}

function dataCalendar(mes, año){
    let data = {
        accion : "calendario",
        departamento: $("#departamentos\\.header").val(),
        mes: mes,
        ano: año
    }

    baseCalendar(mes,año);

    $.post(_api + "/get", data).done(function(response){

        if (Object.keys(response).length > 0) {
            if (response.refuerzo == 1){
                $("#table\\.diurno").attr("colspan",2).html("Turno Diurno");
                $("#table\\.nocturno").attr("colspan",2).removeClass("d-none");
                $("#table\\.turnos").attr("colspan",4)
                $("#table\\.diurno\\.extra").removeClass("d-none");
                $("#table\\.header\\.dia").attr("rowspan",3);
                $("#table\\.header\\.turnos").attr("rowspan",3);
            }
            else if (response.horas == 1){
                $("#table\\.diurno").attr("colspan",1).html("Turno realizado por Dr(a).");
                $("#table\\.nocturno").attr("colspan",1).addClass("d-none");
                $("#table\\.turnos").attr("colspan",1)
                $("#table\\.diurno\\.extra").addClass("d-none");
                $("#table\\.header\\.dia").attr("rowspan",2);
                $("#table\\.header\\.turnos").attr("rowspan",2);
                
            }
            else{
                $("#table\\.diurno").attr("colspan",1).html("Turno Diurno");
                $("#table\\.nocturno").attr("colspan",1).removeClass("d-none");
                $("#table\\.turnos").attr("colspan",2);
                $("#table\\.diurno\\.extra").addClass("d-none");
                $("#table\\.header\\.dia").attr("rowspan",2);
                $("#table\\.header\\.turnos").attr("rowspan",2);
            }

            let _total = new Date(año, (+mes), 0).getDate();
            let H = 1;

            for (H; H <= _total; H++){
                let fila = "";

                //filtrar todos los turnos del dia
                const turnoDia = filtrarDia(response.calendario, H, mes, año);
                const fecha = año + "-" + mes + "-" + ("0" + H).slice(-2);
                
                if (turnoDia.length > 0){
                    //filtrar primero los turnos programados
                    const programadoDia = filtrarProgramados(turnoDia);

                    fila = crearFilaCalendario(programadoDia, fecha, "programado", response.horas);

                    //filtrar los realizados
                    const realizadosDia = filtrarRealizados(turnoDia);

                    if (realizadosDia.length > 0){

                        //filtrar los realizados de dia y que no son de refuerzo
                        const dia = realizadosDia.filter(turno => {
                            return turno.turno_periodo === "0" && turno.turno_refuerzo === "0";
                        });

                        fila += crearFilaCalendario(dia, fecha, "diurno", response.horas);

                        if (response.refuerzo == 1){
                            //filtrar los realizados de dia y que son de refuerzo
                            const diaR = realizadosDia.filter(turno => {
                                return turno.turno_periodo === "0" && turno.turno_refuerzo === "1";
                            });
    
                            fila += crearFilaCalendario(diaR, fecha, "diurnor", response.horas);
                        }

                        //filtrar los realizados de noche y que no son de refuerzo
                        const noche = realizadosDia.filter(turno => {
                            return turno.turno_periodo === "1" && turno.turno_refuerzo === "0";
                        });
                        
                        fila += crearFilaCalendario(noche, fecha, "nocturno", response.horas);

                        if (response.refuerzo == 1){
                            //filtrar los realizados de dia y que son de refuerzo
                            const nocheR = realizadosDia.filter(turno => {
                                return turno.turno_periodo === "1" && turno.turno_refuerzo === "1";
                            });

                            fila += crearFilaCalendario(nocheR, fecha, "nocturnor", response.horas);
                        }
                    }
                    else{
                        if (response.refuerzo == 1){
                            fila += '<td data-diurno="1" class="bg-light" data-fecha="'+ fecha +'"></td><td data-diurnor="1"  data-fecha="'+ fecha +'"></td><td data-nocturno="1" class="bg-light" data-fecha="'+ fecha +'"></td><td data-nocturnor="1"  data-fecha="'+ fecha +'"></td>';
                        }
                        else if (response.horas == 1){
                            fila += '<td data-programado="1" data-fecha="'+ fecha +'"></td><td data-diurno="1" class="bg-light" data-fecha="'+ fecha +'"></td></td>';
                        }
                        else{
                            fila += '<td data-diurno="1" class="bg-light" data-fecha="'+ fecha +'"></td><td data-nocturno="1" class="bg-light" data-fecha="'+ fecha +'"></td>';
                        }
                    }
                }
                else{
                    if (response.refuerzo == 1){
                        fila = '<td data-programado="1" data-fecha="'+ fecha +'"></td><td data-diurno="1" class="bg-light" data-fecha="'+ fecha +'"></td><td data-diurnor="1"  data-fecha="'+ fecha +'"></td><td data-nocturno="1" class="bg-light" data-fecha="'+ fecha +'"></td><td data-nocturnor="1"  data-fecha="'+ fecha +'"></td>';
                    }
                    else if (response.horas == 1){
                        fila = '<td data-programado="1" data-fecha="'+ fecha +'"></td><td data-diurno="1" class="bg-light" data-fecha="'+ fecha +'"></td></td>';
                    }
                    else{
                        fila = '<td data-programado="1" data-fecha="'+ fecha +'"></td><td data-diurno="1"  class="bg-light" data-fecha="'+ fecha +'"></td><td data-nocturno="1"  class="bg-light" data-fecha="'+ fecha +'"></td>';
                    }
                }
                $("#table\\.calendario tr:nth-child(" + H + ")").append(fila);
            }

            $("#table\\.calendario tr td").on("click", function(){
                let fecha = $(this).data("fecha");
                let categoria = "";
                let periodo = "";
                let completo = 0;
                 
                let programado = $(this).data("programado");
                let diurno = $(this).data("diurno");
                let diurnor = $(this).data("diurnor");
                let nocturno = $(this).data("nocturno");
                let nocturnor = $(this).data("nocturnor");
                completo = $(this).data("completo");

                if (programado == 1){
                    categoria = "Turno programado";
                }
                else {
                    categoria = "Turno realizado";
                }

                if (diurno == 1){
                    periodo = "Diurno";
                }
                else if (nocturno == 1){
                    periodo = "Nocturno";
                }
                else if (diurnor == 1){
                    periodo = "Diurno refuerzo";
                }
                else if (nocturnor == 1){
                    periodo = "Nocturno refuerzo";
                }
                if (programado == 1 || completo == 1) { periodo = "Completo 24 hrs."; }

                $("#dialog\\.title").html("INGRESAR DATOS<br>(Departamento, fecha de turno, horario y profesional asignado)");
                $("#dialog\\.body").html('<p class="text-danger text-center">Cargando</p>');
                $("#dialog\\.footer").html('');
                $("#dialog\\.view").modal("show");

                    let elPeriodo = diurno == 1 ? 0: 1;
                    let elRefuerzo = 0;
                    let laCategoria = 1;
                    
                    if (diurnor == 1){
                        elPeriodo = 0;
                        elRefuerzo = 1;
                    }
                    else if (nocturnor == 1){
                        elPeriodo = 1;
                        elRefuerzo = 1;
                    }

                    if (programado == 1){
                        elPeriodo = 0;
                        laCategoria = 0;
                    }

                    let data = {
                        accion : "turno",
                        departamento: $("#departamentos\\.header").val(),
                        fecha: fecha,
                        categoria: laCategoria,
                        periodo: elPeriodo,
                        refuerzo: elRefuerzo
                    }

                    $.post(_api + "/get", data).done(function(response){
                        $("#dialog\\.body").html('<div role="group" class="btn-group my-2"><button type="button" class="btn btn-primary" id="turno.nuevo">Nuevo Turno</button><button type="button" class="btn btn-primary d-none" id="turno.guardar">Guardar</button><button type="button" class="btn btn-secondary d-none" id="turno.cancelar">Cancelar</button></div><div class="card d-none" id="turno.card"><div class="card-body"><h5 class="card-title">Nuevo Turno</h5><input class="form-control" type="hidden" id="hidden.turno.periodo"><input class="form-control" type="hidden" id="hidden.turno.refuerzo"><input class="form-control" type="hidden" id="hidden.turno.categoria"><input class="form-control" type="hidden" id="hidden.turno.fecha"><input class="form-control" type="hidden" id="hidden.turno.departamento"> <div class="row"><div class="form-group col-6" id="turno.div.profesional.grupo"><label for="turno.profesional.grupo">Grupo del Profesional asignado</label><select class="form-control" id="turno.profesional.grupo"><option value="0" selected>Titular</option><option value="1">Reemplazante</option></select></div><div class="form-group col-6"><label for="turno.profesional">Profesional asignado</label><select class="form-control" id="turno.profesional"><option value="0" selected>Cargando...</option></select></div><div class="form-group col-6"><label for="turno.horas">Horas</label><select class="form-control" id="turno.horas"><option value="1">1 hora</option><option value="2">2 hora</option><option value="3">3 hora</option><option value="4">4 hora</option><option value="5">5 hora</option><option value="6">6 hora</option><option value="7">7 hora</option><option value="8">8 hora</option><option value="9">9 hora</option><option value="10">10 hora</option><option value="11">11 hora</option><option value="12">12 hora</option></select></div><div class="form-group col-6"><label for="turno.departamento">Departamento</label><input class="form-control" type="text" id="turno.departamento" disabled=""></div><div class="form-group col-6"><label for="turno.fecha">Fecha de turno</label><input class="form-control" type="date" id="turno.fecha" disabled=""></div><div class="form-group col-6"> <label for="turno.categoria">Categoria</label> <input class="form-control" type="text" id="turno.categoria" disabled=""></div><div class="form-group col-6"> <label for="turno.periodo">Periodo</label> <input class="form-control" type="text" id="turno.periodo" disabled=""></div></div></div></div><table class="table my-2"><thead class="thead-light"><tr><th scope="col">Profesional</th><th scope="col">Turno</th><th scope="col">Horas</th><th scope="col">Refuerzo</th><th scope="col">Acciones</th></tr></thead><tbody id="turno.tabla"></tbody></table>');

                        if (laCategoria == 0 || completo == 1){
                            let H = 1;
                            for (H; H <= 12; H++){
                                $("#turno\\.horas").append('<option value="' + (H + 12) +'">' + (H + 12) + ' hora</option>');
                            }
                            $("#turno\\.horas option:nth-child(24)").prop('selected', true);
                            if (laCategoria == 0){
                                $("#turno\\.div\\.profesional\\.grupo").addClass("d-none");
                            }
                        }
                        else{
                            $("#turno\\.horas option:nth-child(12)").prop('selected', true);
                        }

                        let reemplazante = $("#departamentos\\.header option:selected").data("reemplazante");
                        if (!!+reemplazante == false){
                            $("#turno\\.div\\.profesional\\.grupo").addClass("d-none");
                        } 

                        $("#turno\\.departamento").val($("#departamentos\\.header option:selected").text());
                        $("#turno\\.fecha").val(fecha);
                        $("#turno\\.categoria").val(categoria);
                        $("#turno\\.periodo").val(periodo);
                        profesionales("#turno\\.profesional", $("#departamentos\\.header").val(), $("#turno\\.profesional\\.grupo").val());
    
                        $("#hidden\\.turno\\.departamento").val($("#departamentos\\.header").val());
                        $("#hidden\\.turno\\.fecha").val(fecha);
                        $("#hidden\\.turno\\.categoria").val(laCategoria);
                        $("#hidden\\.turno\\.periodo").val(elPeriodo);
                        $("#hidden\\.turno\\.refuerzo").val(elRefuerzo);

                        $("#turno\\.profesional\\.grupo").on("change", function(){
                            profesionales("#turno\\.profesional", $("#departamentos\\.header").val(), $("#turno\\.profesional\\.grupo").val());
                        });

                        $("#turno\\.nuevo").on("click", function(){
                            $("#turno\\.nuevo").addClass("d-none");
                            $("#turno\\.guardar").removeClass("d-none");
                            $("#turno\\.cancelar").removeClass("d-none");
                            $("#turno\\.card").removeClass("d-none");
                        });

                        $("#turno\\.guardar").on("click", function(){
                            $("#turno\\.nuevo").removeClass("d-none");
                            $("#turno\\.guardar").addClass("d-none");
                            $("#turno\\.cancelar").addClass("d-none");
                            $("#turno\\.card").addClass("d-none");

                            let data = {
                                accion : "turno",
                                departamento: $("#departamentos\\.header").val(),
                                fecha: $("#hidden\\.turno\\.fecha").val(),
                                categoria: $("#hidden\\.turno\\.categoria").val(),
                                profesional: $("#turno\\.profesional").val(),
                                horas: $("#turno\\.horas").val(),
                                periodo: $("#hidden\\.turno\\.periodo").val(),
                                refuerzo: $("#hidden\\.turno\\.refuerzo").val()
                            }
    
                            $.post(_api + "/set", data).done(function(response){
                                if (Object.keys(data).length > 0) {
                                    let mes = $("#fecha\\.mes").val();
                                    let año = $("#fecha\\.ano").val();
                                    dataCalendar(mes,año);
                                }
                            });
    
                            $("#dialog\\.view").modal("hide");
                        });

                        $("#turno\\.cancelar").on("click", function(){
                            $("#turno\\.nuevo").removeClass("d-none");
                            $("#turno\\.guardar").addClass("d-none");
                            $("#turno\\.cancelar").addClass("d-none");
                            $("#turno\\.card").addClass("d-none");
                        });

                        tablaTurnos(response);
                    });
            });
        }
    });
}

function filtrarDia(data, dia, mes, año){

    let filtro = data.filter(turno => {
        let fecha = año + '-' + mes + '-' + ("0" + dia).slice(-2);
        return turno.turno_fecha === fecha;
    });

    return filtro;
}

function filtrarProgramados(data){
    
    let filtro = data.filter(turno => {
        return turno.turno_categoria === "0";
    });

    return filtro;
}

function filtrarRealizados(data){
    
    let filtro = data.filter(turno => {
        return turno.turno_categoria === "1";
    });

    return filtro;
}

function tablaTurnos(data){
    $("#turno\\.tabla").empty();
    if (Object.keys(data).length > 0) {
        $.each(data, function(i,value){
            let periodo = value.turno_periodo == 0 ? "Diurno" : "Nocturno";
            let refuerzo = value.turno_refuerzo == 0 ? "No" : "Si";

            let fila = '<tr><td>' + value.user_nombre + '</td><td>' + periodo + '</td><td>' + value.turno_horas + '</td><td>'+ refuerzo +'</td><td><button class="btn btn-danger eliminar-turno" data-id="'+ value.turno_id+'">Eliminar</button></td></tr>';
            $("#turno\\.tabla").append(fila);
        });

        $(".eliminar-turno").on("click", function(){
            let id = $(this).data("id");
            $(this).text("Eliminando..");
            $(".eliminar-turno").prop('disabled', true);
            
            $("body").append('<div class="modal" tabindex="-1" role="dialog" id="alerta.view"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="alerta.title">Pregunta</h4><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="modal-body" id="alerta.body">¿Está seguro?</div><div class="modal-footer" id="alerta.footer"></div></div></div></div>');
            $("#alerta\\.footer").html('<button id="alerta.eliminar" class="btn btn-secondary" data-id="' + id + '">Eliminar</button><button class="btn btn-danger" id="alerta.cancelar">Cancelar</button>');
            $("#alerta\\.eliminar").on("click", function(){
                let send = {
                    accion : "turno",
                    turno_id: id
                }
    
                $.post(_api + "/delete", send).done(function(response){
                    tablaTurnos(response);
                    let mes = $("#fecha\\.mes").val();
                    let año = $("#fecha\\.ano").val();
                    dataCalendar(mes,año);
                    $("#alerta\\.view").modal("hide").remove();
                    $("#dialog\\.view").modal("hide");
                });
            });

            $("#alerta\\.cancelar").on("click", function(){
                $("#alerta\\.view").modal("hide").remove();
                $(".eliminar-turno").prop('disabled', false).text("Eliminar");
            });
            $("#alerta\\.view").modal("show");
        });
    }
}

function crearFilaCalendario(data, fecha, tipo, horas){
    let fila = "";
    var clase = "";

    if (tipo == "diurno" || tipo == "nocturno"){
        clase = "bg-light";
    }

    if (data.length > 0){
        let a = 0;
        if (data.length > 1){
            fila += '<td class="'+ clase +'" data-'+ tipo +'="1" data-fecha="'+ fecha +'" data-completo="'+ horas +'">';
            for (a; a < data.length; a++){
                fila += '<p class="mb-0">' + data[a].user_nombre +' <span class="badge badge-pill badge-dark">' + data[a].turno_horas +' hrs.</span></p>';
            }
            fila += '</td>';
        }
        else{
            fila += '<td class="'+ clase +'" data-'+ tipo +'="1" data-fecha="'+ fecha +'"><p class="mb-0">' + data[0].user_nombre +' <span class="badge badge-pill badge-dark">' + data[a].turno_horas +' hrs.</span></p></td>';
        }
    }
    else if(horas == 1){
        fila = '';
    }
    else{
        fila += '<td class="'+ clase +'" data-'+ tipo +'="1" data-fecha="'+ fecha +'"></td>';
    }

    return fila;
}