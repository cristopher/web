import { make, the, inputDate, humanDate, toDate } from './wetrust.js'

let _fecha = new Date()

the("fecha").value = inputDate(_fecha)

$(document).ready(function(){
    departamentos();

    $("#fecha").on("change", function(){
        $("#departamento").trigger("change")
    })

    $("#departamento").on("change", function(){
        turnos_dia(this.value)

        let categoria = +this.options[this.selectedIndex].dataset.categoria;
        let comentario = +this.options[this.selectedIndex].dataset.comentario;
        let jornada = +this.options[this.selectedIndex].dataset.jornada;

        if (categoria == 0){
            $("#tercera\\.cabecera").addClass("d-none");
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",2);
            $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",1);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",1).attr("rowspan",2)

            if (comentario == 1){
                $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",2);
                $("#segunda\\.cabecera\\.segunda\\.columna").removeClass("d-none");
            }else{
                $("#segunda\\.cabecera\\.segunda\\.columna").addClass("d-none"); 
            }
            $("#segunda\\.cabecera\\.tercera\\.columna").addClass("d-none");
            $("#segunda\\.cabecera\\.cuarta\\.columna").addClass("d-none");
        } else if (categoria == 1){
            $("#tercera\\.cabecera").addClass("d-none");
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",2);
            $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",1);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",2).attr("rowspan",1)
            $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",1);
            $("#segunda\\.cabecera\\.segunda\\.columna").attr("colspan",1);
            $("#segunda\\.cabecera\\.tercera\\.columna").attr("colspan",1).removeClass("d-none");
            $("#segunda\\.cabecera\\.cuarta\\.columna").attr("colspan",1).removeClass("d-none");
            if (comentario == 1){
                $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",2); 
                $("#segunda\\.cabecera\\.segunda\\.columna").removeClass("d-none");
                $("#segunda\\.cabecera\\.segunda\\.columna").attr("rowspan",1);
            }else{
                $("#segunda\\.cabecera\\.segunda\\.columna").addClass("d-none"); 
            }
        } else if (categoria == 2){
            $("#tercera\\.cabecera").removeClass("d-none");
            $("#primera\\.cabecera\\.primera\\.columna").attr("rowspan",3);
            $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",2);
            $("#primera\\.cabecera\\.tercera\\.columna").attr("colspan",4).attr("rowspan",1)
            $("#segunda\\.cabecera\\.primera\\.columna").attr("colspan",2);
            $("#segunda\\.cabecera\\.tercera\\.columna").attr("colspan",2).removeClass("d-none");
            $("#segunda\\.cabecera\\.cuarta\\.columna").attr("colspan",2).removeClass("d-none");
            if (comentario == 1){
                $("#primera\\.cabecera\\.segunda\\.columna").attr("colspan",3); 
                $("#segunda\\.cabecera\\.segunda\\.columna").removeClass("d-none"); 
                $("#segunda\\.cabecera\\.segunda\\.columna").attr("rowspan",2);  
            }
            else{
                $("#segunda\\.cabecera\\.segunda\\.columna").addClass("d-none"); 
            }
        }

        if (jornada == 1){
            $("#segunda\\.cabecera\\.tercera\\.columna").html("Turno Diurno");
            $("#segunda\\.cabecera\\.cuarta\\.columna").html("Turno Nocturno");
        }else{
            $("#segunda\\.cabecera\\.tercera\\.columna").html("Turno Mañana");
            $("#segunda\\.cabecera\\.cuarta\\.columna").html("Turno Tarde");
        }

    });
});

function filtrarDia(data, fecha){
    let filtro = data.filter(turno => { return turno.turno_fecha === fecha; });
    return filtro;
}

function filtrarProgramados(data){
    let filtro = data.filter(turno => { return turno.turno_categoria === "0"; });
    return filtro;
}

function crearFilaCalendario(data, tipo, fecha){
    var clase = "";
    var fila = "";
    if (tipo == 1 || tipo == 3){
        clase = "bg-light";
    }

    if (data.length > 0 && tipo != 6){
        let a = 0;
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'">';
        for (a; a < data.length; a++){
            fila += '<p class="mb-0">' + data[a].user_name +' <span class="badge badge-pill badge-dark">' + data[a].turno_horas +' hrs.</span></p>';
        }
        fila += '</td>';
    }
    else if (data.length > 0 && tipo == 6){
        let a = 0;
        fila += '<td class="comentario '+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'">';
        for (a; a < data.length; a++){

            let coment = (data[a].turno_comentario.length > 0) ? data[a].turno_comentario.replace(/(?:\r\n|\r|\n)/g, '<br>') : data[a].turno_comentario;
            
            fila += '<p class="mb-0">' + coment +' </p>';
        }
        fila += '</td>';
    } else{
        fila += '<td class="'+ clase +'" data-categoria="'+ tipo +'" data-fecha="'+ fecha +'"></td>';
    }
    return fila;
}

function baseCalendar(){

    var _año = toDate(the("fecha").value).getFullYear();
    var _mes = (toDate(the("fecha").value).getMonth()+1);
    var cuantosDiasMes = new Date(_año, _mes, 0).getDate();
    let dias = ["Domingo ","Lunes ", "Martes ", "Miércoles ", "Jueves ", "Viernes ", "Sábado "];
    let _total = toDate(the("fecha").value).getDate() + 6;
    let _primer = toDate(the("fecha").value).getDay();
    let _dia = toDate(the("fecha").value).getDate();

    $("#table\\.calendario").empty();

    for (_dia; _dia <= _total; _dia++){
        let internal_dia = _dia;

        if (_dia > cuantosDiasMes){
            _dia = (_dia - cuantosDiasMes);
        }
        let rojo = "";
        if (_primer == 0 || _primer == 6){
            rojo = "text-danger";
        }
        let fila = '<tr><td class="bg-light ' + rojo +'">' + dias[_primer] + " " + _dia + "</td></tr>";

        $("#table\\.calendario").append(fila);
        _primer = _primer == 6 ? 0 : _primer + 1 ;
        _dia = internal_dia;
    }
}

function departamentos(){
    let data = new FormData()

    data.append("accion", "departamentos")

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {
        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.departamento_id + '" data-categoria="' + item.departamento_categoria + '" data-jefe="' + item.departamento_eljefe + '" data-hora-asignada="' + item.departamento_horas_asignadas + '" data-hora-realizada="' + item.departamento_horas_realizadas + '" data-comentario="' + item.departamento_comentarios + '" data-hora-refuerzo="' + item.departamento_horas_refuerzo + '" data-jornada="'+item.departamento_jornada+'">' + item.departamento_name + '</option>';
                $("#departamento").append(option);
            });
            $("#departamento").trigger("change");
        }
    }).catch(function(error) {
        alert("error")
    });
}

function turnos_dia(departamento){
    let data = new FormData()

    data.append("accion", "turno_dias")
    data.append("departamento", departamento)
    data.append("fecha", the("fecha").value)

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        baseCalendar();

        var _año = toDate(the("fecha").value).getFullYear();
        var _mes = (toDate(the("fecha").value).getMonth()+1);
        var cuantosDiasMes = new Date(_año, _mes, 0).getDate();
        let _total = toDate(the("fecha").value).getDate() + 6;
        let _dia = toDate(the("fecha").value).getDate();                
        var mesCambiado = false;

        let categoria = $("#departamento option:selected").data("categoria");
        let comentario = +$("#departamento option:selected").data("comentario");
        let contador = 1;

        for (_dia; _dia <= _total; _dia++){
            let internal_dia = _dia;

            if (_dia > cuantosDiasMes){
                _dia = (_dia - cuantosDiasMes);
                if (mesCambiado == false){
                    _mes++;
                    mesCambiado = true;
                    if (_mes == 13){
                        _año++;
                        _mes--;
                    }
                }
            }

            const fecha = _año + "-" + ("0" + _mes).slice(-2) + "-" + ("0" + _dia).slice(-2);
            const turnoDia = filtrarDia(data, fecha);
            const programadoDia = filtrarProgramados(turnoDia);
            let fila = '';

            fila += crearFilaCalendario(programadoDia, 0, fecha);

            const asignadoRefuerzo = turnoDia.filter(turno => { return turno.turno_categoria === "5"; });
            const comentarios = turnoDia.filter(turno => { return turno.turno_categoria === "6"; });
            const uno = turnoDia.filter(turno => { return turno.turno_categoria === "1"; });
            const dos = turnoDia.filter(turno => { return turno.turno_categoria === "2"; });
            const tres = turnoDia.filter(turno => { return turno.turno_categoria === "3"; });
            const cuatro = turnoDia.filter(turno => { return turno.turno_categoria === "4"; });

            if (categoria == 1){
                if (comentario == 1){
                    fila += crearFilaCalendario(comentarios, 6, fecha);
                }
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
            } else if (categoria == 2){
                fila += crearFilaCalendario(asignadoRefuerzo, 5, fecha);
                if (comentario == 1){
                    fila += crearFilaCalendario(comentarios, 6, fecha);
                }
                fila += crearFilaCalendario(uno, 1, fecha);
                fila += crearFilaCalendario(dos, 2, fecha);
                fila += crearFilaCalendario(tres, 3, fecha);
                fila += crearFilaCalendario(cuatro, 4, fecha);
            } else {
                if (comentario == 1){ fila += crearFilaCalendario(comentarios, 6, fecha); }
                fila += crearFilaCalendario(uno, 1, fecha);
            }

            $("#table\\.calendario tr:nth-child(" + contador + ")").append(fila);
            contador++;
            _dia = internal_dia;
        }
    }).catch(function(error) {
        alert("error")
    });
}