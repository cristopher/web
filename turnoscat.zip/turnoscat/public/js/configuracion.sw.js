var apikey = "";
addEventListener('message', function(e) {
    var data = e.data;
    switch (data.cmd) {
        case 'start':
            postMessage('WORKER STARTED: ' + data.msg);
            break;
    }
}, false);

GetProfesionales
UpdateProfesionales
GetDepartamentos
UpdateProfesionales

function api(apikey, url){
    fetch(url)
    .then(function(response) {
      return response.json();
    })
    .catch(err => {
        self.postMessage(err.message);
    });
}

