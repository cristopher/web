$(document).ready(function(){ 
    $("#fecha\\.uno").on("change", function(){
        horas();
    });
    $("#fecha\\.dos").on("change", function(){
        horas();
    });

    $("#horas\\.imprimir").on("click", function(){
        var ventimp = window;
        ventimp.print();
    });

    var now = new Date();

    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;

    $("#fecha\\.dos").val(today);
    $("#fecha\\.uno").val(today);
    horas();

});

function horas(){
    let data = {
        accion : "horasdpto",
        fechauno : $("#fecha\\.uno").val(),
        fechados : $("#fecha\\.dos").val()
    }

    $.post(_api + "/get", data).done(function(response){
        $("#table\\.calendario").empty();

        if (Object.keys(response).length > 0) {
            var total_titular = 0;
            var total_refuerzo = 0;
            var total_horas_titular = 0;
            var total_horas_refuerzo = 0;
            var sumatotal = 0;
            $.each(response, function(i, item) {
                let option = "";
                let totalDepartamento = 0 
                if (parseInt(item.turno_refuerzo) > 0){
                    totalDepartamento = parseInt(item.turno_titular) + parseInt(item.turno_refuerzovalor);
                    option = '<tr class="bg-light"><td>' + item.departamento_name + '</td><td>' + item.turno_horas + ' horas </td><td>$ '+ item.turno_titular.toLocaleString() +'</td><td>' +item.turno_refuerzo +' horas </td><td>$ '+ item.turno_refuerzovalor.toLocaleString() +'</td><td>' + totalDepartamento.toLocaleString() +'</td><tr>';
                }
                else{
                    totalDepartamento = parseInt(item.turno_titular) + parseInt(item.turno_refuerzovalor);
                    option = '<tr><td>' + item.departamento_name + '</td><td>' + item.turno_horas + ' horas </td><td>$ '+ item.turno_titular.toLocaleString() +'</td><td>' +item.turno_refuerzo +' horas </td><td>$ '+ item.turno_refuerzovalor.toLocaleString() +'</td><td>' + totalDepartamento.toLocaleString() +'</td><tr>';
                }

                sumatotal += totalDepartamento;
                
                total_titular += item.turno_titular;
                total_refuerzo += item.turno_refuerzovalor;
                total_horas_titular += parseInt(item.turno_horas);
                total_horas_refuerzo += parseInt(item.turno_refuerzo);
                $("#table\\.calendario").append(option);
            });

            let option = '<tr class="bg-light"><td>Total</td><td>' + total_horas_titular + ' horas</td><td>$ '+ total_titular.toLocaleString() +'</td><td>' + total_horas_refuerzo + ' horas</td><td>$ '+ total_refuerzo.toLocaleString() +'</td><td class="bg-dark text-white">'+ sumatotal.toLocaleString() +'</td><tr>';
            $("#table\\.calendario").append(option);
        }
    });
}  