$(document).ready(function(){
    departamentos();
    $("#departamentos\\.header").on("change", function(){
        horas();
    });
    $("#fecha\\.uno").on("change", function(){
        horas();
    });
    $("#fecha\\.dos").on("change", function(){
        horas();
    });

    $("#horas\\.imprimir").on("click", function(){
        var ventimp = window;
        ventimp.print();
    });

    var now = new Date();

    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;

    $("#fecha\\.dos").val(today);
    $("#fecha\\.uno").val(today);
    horas();
});

function horas(){
    let data = {
        accion : "horas",
        departamento : $("#departamentos\\.header").val(),
        fechauno : $("#fecha\\.uno").val(),
        fechados : $("#fecha\\.dos").val()
    }

    $.post(_api + "/get", data).done(function(response){
        $("#table\\.horas").empty();

        if (Object.keys(response).length > 0) {
            $.each(response, function(i, item) {
                let option = '<tr><td>' + item.user_nombre + '</td><td>' + item.horas_titular + ' horas </td><td>' + item.horas_refuerzo+ ' horas </td><tr>';
                $("#table\\.horas").append(option);
            });
        }
    });
}

function departamentos(){
    let data = {
        accion : "departamentos"
    }

    $.post(_api + "/get", data).done(function(response){
        $("#departamentos\\.header").empty();

        if (Object.keys(response).length > 0) {
            $.each(response, function(i, item) {
                let option = '<option value="' + item.departamento_id + '" data-categoria="' + item.departamento_categoria + '">' + item.departamento_name + '</option>';
                $("#departamentos\\.header").append(option);
            });
            $("#departamentos\\.header").trigger("change");
        }
    });
}