<header class="rosa text-white">
    <div class="container">
        <h1>404 - No encontrado</h1>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <p class="text-danger">No existe la página solicitada.</p>
    </div>
</main>
