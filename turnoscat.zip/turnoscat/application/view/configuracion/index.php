<header class="py-4 wetrust">
    <div class="container">
        <h1>Configuración</h1>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <ul class="nav nav-tabs my-2" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#departamento" role="tab" aria-controls="departamento" aria-selected="true">Departamento o unidad</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="empleados-tab" data-toggle="tab" href="#empleados" role="tab" aria-controls="empleados" aria-selected="false">Profesionales asignados a departamento</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="departamento" role="tabpanel" aria-labelledby="departamento-tab">
                <div role="group" class="btn-group my-2">
                    <button type="button" class="btn btn-info" id="departamento.nuevo">Nuevo Departamento</button>
                    <button type="button" class="btn btn-info d-none" id="departamento.guardar">Guardar</button>
                    <button type="button" class="btn btn-secondary d-none" id="departamento.cancelar">Cancelar</button>
                </div>
                <div class="card d-none" id="departamento.card">
                    <div class="card-body">
                        <input class="form-control" type="hidden" id="hidden.departamento.id">
                        <div class="row">
                            <div class="form-group col-6">
                                <label for="departamento.nombre">Nombre del Departamento</label>
                                <input class="form-control" type="text" id="departamento.nombre">
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.jefe">Jefe de departamento</label>
                                <select class="form-control" id="departamento.jefe"></select>
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.horas.asignadas">Horas predeterminadas para turnos asignados </label>
                                <select class="form-control" id="departamento.horas.asignadas"><option value="6">6 hora</option><option value="12">12 hora</option><option value="24">24 hora</option></select>
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.horas.refuerzo.asignadas">Horas predeterminadas para turnos de refuerzo</label>
                                <select class="form-control" id="departamento.horas.refuerzo.asignadas"><option value="6">6 hora</option><option value="12">12 hora</option><option value="24">24 hora</option></select>
                            </div>
                            <div class="form-group col-12">
                                <label for="departamento.categoria">Categoria de departamento (cantidad de columnas)</label>
                                <select class="form-control" id="departamento.categoria"><option value="0">Una columna</option><option value="1">Dos columnas</option><option value="2">Cuatro columnas</option></select>
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.horas">Horas predeterminadas para turnos efectivamente realizados</label>
                                <select class="form-control" id="departamento.horas"><option value="1">1 hora</option><option value="2">2 hora</option><option value="3">3 hora</option><option value="4">4 hora</option><option value="5">5 hora</option><option value="6">6 hora</option><option value="7">7 hora</option><option value="8">8 hora</option><option value="9">9 hora</option><option value="10">10 hora</option><option value="11">11 hora</option><option value="12">12 hora</option><option value="13">13 hora</option><option value="14">14 hora</option><option value="15">15 hora</option><option value="16">16 hora</option><option value="17">17 hora</option><option value="18">18 hora</option><option value="19">19 hora</option><option value="20">20 hora</option><option value="21">21 hora</option><option value="22">22 hora</option><option value="23">23 hora</option><option value="24">24 hora</option></select>
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.horas.refuerzo">Horas predeterminadas para turnos de refuerzo efectivamente realizados</label>
                                <select class="form-control" id="departamento.horas.refuerzo"><option value="1">1 hora</option><option value="2">2 hora</option><option value="3">3 hora</option><option value="4">4 hora</option><option value="5">5 hora</option><option value="6">6 hora</option><option value="7">7 hora</option><option value="8">8 hora</option><option value="9">9 hora</option><option value="10">10 hora</option><option value="11">11 hora</option><option value="12">12 hora</option><option value="13">13 hora</option><option value="14">14 hora</option><option value="15">15 hora</option><option value="16">16 hora</option><option value="17">17 hora</option><option value="18">18 hora</option><option value="19">19 hora</option><option value="20">20 hora</option><option value="21">21 hora</option><option value="22">22 hora</option><option value="23">23 hora</option><option value="24">24 hora</option></select>
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.jornada">Tipo de jornada</label>
                                <select class="form-control" id="departamento.jornada">
                                    <option value="1">Diurno / Nocturno</option>
                                    <option value="2">Mañana / Tarde</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-6">
                                <label for="departamento.nombre">Valor Turno titular</label>
                                <input class="form-control" type="number" id="departamento.valor.titular">
                            </div>
                            <div class="form-group col-6">
                                <label for="departamento.jefe">Valor Turno refuerzo</label>
                                <input class="form-control" type="number" id="departamento.valor.refuerzo">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-6">
                                <label for="departamento.comentario">Activar Distribución Horaria</label>
                                <select class="form-control" id="departamento.comentario">
                                    <option value="0">No</option>
                                    <option value="1">Si</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <table class="table my-2 table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">Departamento</th>
                            <th scope="col">Columnas por departamento</th>
                            <th scope="col">Acciones relativas al departamento</th>
                        </tr>
                    </thead>
                    <tbody id="departamento.tabla">
                        <tr>
                            <td colspan="4" class="text-center text-danger">Cargando</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade" id="empleados" role="tabpanel" aria-labelledby="empleados-tab">
                <input class="form-control" type="hidden" id="hidden.departamento.id">
                <div class="d-flex justify-content-center">
                    <div class="form-group">
                        <label for="empleados.departamentos">Seleccione departamento</label>
                        <select class="form-control" id="empleados.departamentos"></select>
                    </div>
                </div>
                <div role="group" class="btn-group my-2">
                    <button type="button" class="btn btn-info" id="empleados.nuevo">Vincular un profesional al departamento</button>
                    <button type="button" class="btn btn-info d-none" id="empleados.guardar">Guardar</button>
                    <button type="button" class="btn btn-secondary d-none" id="empleados.cancelar">Cancelar</button>
                </div>
                <div class="card d-none" id="empleados.card">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-6">
                                <label for="empleados.profesionales">Profesionales</label>
                                <select class="form-control" id="empleados.profesionales"></select>
                            </div>
                        </div>
                    </div>
                </div>
                <table class="table my-2 table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">Nombre profesional</th>
                            <th scope="col">Teléfono</th>
                            <th scope="col">Correo</th>
                            <th scope="col">Acciones relativas al profesional</th>
                        </tr>
                    </thead>
                    <tbody id="empleados.tabla">
                        <tr>
                            <td colspan="4" class="text-center text-danger">Cargando</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
</script>
<script src="js/configuracion.departamentos.js"></script>
<script src="js/configuracion.profesionales.js"></script>