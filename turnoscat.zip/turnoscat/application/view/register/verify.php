<header class="py-4 wetrust">
    <div class="container">
        <h1>Verificación</h1>
    </div>
</header>
<main class="minimo">
    <div class="container pt-2">
        <?php $this->renderFeedbackMessages(); ?>
        <a class="btn btn-outline-danger" href="<?php echo Config::get('URL'); ?>">Volver al inicio</a>
    </div>
</main>