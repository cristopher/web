<header class="py-4 wetrust sticky-top">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="mt-2">Usuarios en <?= $this->departamento->departamento_name; ?></h2>
            <a class="btn btn-outline-light" href="<?= Config::get('URL'); ?>">Volver</a>
        </div>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <table class="table table-hover shadow">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Nombre profesional</th>
                    <th scope="col">Teléfono</th>
                    <th scope="col">Email</th>
                </tr>
            </thead>
            <tbody id="usuarios">
            <?php foreach($this->usuarios as $key => $value) { ?>
                <tr>
                    <td><?= $value->user_name; ?></td>
                    <td><?= htmlentities($value->user_phone); ?></td>
                    <td><?= htmlentities($value->user_email); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>