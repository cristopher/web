<h3 class="text-center">Calendario de Turnos Clinica Alemana Temuco, Mes <span id="meses"></span><br>Unidad o Departamento "<?php echo $this->departamento; ?>"</h3>
<p>&nbsp;</p>
<table class="table table-bordered table-hover">
    <thead class="bg-light">
        <tr>
            <th class="text-secondary text-center" scope="col">Profesionales</th>
            <th class="text-secondary text-center" scope="col">Horas</th>
        </tr>
    </thead>
    <tbody id="table.calendario">
        <tr>
            <td colspan="6" class="text-center text-danger">Cargando...</td>
        </tr>
    </tbody>
</table>
<p>&nbsp;</p>
<div class="row">
    <div class="col px-5">
        <p class="mb-0 text-center" id="fecha"></p>
        <hr>
        <p class="text-center">Fecha</p>
    </div>
    <div class="col px-5">
        <p class="mb-0 text-center"><?php echo $this->jefe; ?></p>
        <hr>
        <p class="text-center">V° B° Jefe Unidad</p>
    </div>
</div>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
    var month = '<?php echo $this->mes; ?>';
    var year = '<?php echo $this->año; ?>';
    var departament = "<?php echo $this->departament; ?>";
    var group = "<?php echo $this->grupo; ?>";
</script>
<script src="js/horas.js"></script>