<header class="py-4 wetrust sticky-top">
    <div class="container">
        <?php if (Session::get('user_account_type') > 1) { ?>
            <h2 class="mt-2">TURNOS</h2>
            <div class="form-row align-items-center">
                <div class="col-12 col-sm-4">
                    <div class="form-group">
                        <label for="departamentos.header">Elegir departamento o unidad</label>
                        <select id="departamentos.header" class="form-control"><option value="0">Cargando....</option></select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="fecha.mes">Mes</label>
                        <select id="fecha.mes" class="form-control"><option value="01">Enero</option><option value="02">Febrero</option><option value="03">Marzo</option><option value="04">Abril</option><option value="05">Mayo</option><option value="06">Junio</option><option value="07">Julio</option><option value="08">Agosto</option><option value="09">Septiembre</option><option value="10">Octubre</option><option value="11">Noviembre</option><option value="12">Diciembre</option></select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="fecha.ano">Año</label>
                        <select id="fecha.ano" class="form-control"><option value="2017">2017</option><option value="2018">2018</option><option value="2019">2019</option><option value="2020" selected>2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option></select>
                    </div>
                </div>
                <div class="col-1 d-none" id="boton.ver.esclavos">
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <a id="esclavos" href="#" class="form-control btn btn-outline-light" title="Ver todos los usurios de este departamento"><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-file-earmark-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M4 0h5.5v1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h1V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2z"/><path d="M9.5 3V0L14 4.5h-3A1.5 1.5 0 0 1 9.5 3z"/><path fill-rule="evenodd" d="M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M8 12c4 0 5 1.755 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-.245S4 12 8 12z"/></svg></a>
                    </div>
                </div>
                <div class="col-1 d-none" id="boton.ver.hora">
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <a id="trabajo" href="#" class="form-control btn btn-outline-light" title="Horas trabajadas en el presente mes"><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-clock" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm8-7A8 8 0 1 1 0 8a8 8 0 0 1 16 0z"/><path fill-rule="evenodd" d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5z"/></svg></a>
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <h4 class="mt-2">DISTRIBUCIÓN DE TURNOS PRÓXIMOS 7 DÍAS <small>(Elegir departamento y fecha de inicio)</small></h4>
            <div class="row">
                <div class="col-6 form-group">
                    <label>Seleccionar departamento</label>
                    <select class="form-control" id="departamento">
                    </select>
                </div>
                <div class="col-3 form-group">
                    <label>Fecha de inicio</label>
                    <input class="form-control" type="date" id="fecha">
                </div>
            </div>
        <?php } ?>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <table class="table table-bordered table-hover shadow">
            <thead class="bg-light">
                <tr>
                    <th class="text-secondary text-center" id="primera.cabecera.primera.columna">Días del turno</th>
                    <th class="text-secondary text-center" id="primera.cabecera.segunda.columna">Turnos asignados según rotativa estándar</th>
                    <th class="text-secondary text-center" id="primera.cabecera.tercera.columna">Turnos efectivamente realizados</th>
                </tr>
                <tr>
                    <th class="text-secondary text-center" id="segunda.cabecera.primera.columna">Médico</th>
                    <th class="text-secondary text-center d-none comentario" id="segunda.cabecera.segunda.columna">Distribución Horaria</th>
                    <th class="text-secondary text-center" id="segunda.cabecera.tercera.columna">Turno Diurno</th>
                    <th class="text-secondary text-center" id="segunda.cabecera.cuarta.columna">Turno Nocturno</th>
                </tr>
                <tr id="tercera.cabecera" class="d-none">
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                </tr>
            </thead>
            <tbody id="table.calendario">
                <tr><td colspan="6" class="text-center text-danger">Cargando...</td></tr>
            </tbody>
        </table>
    </div>
</main>
<div class="modal" tabindex="-1" role="dialog" id="dialog.view">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header wetrust">
                <h4 class="modal-title mx-auto" id="dialog.title"></h4>
            </div>
            <div class="modal-body" id="dialog.body">
            </div>
            <div class="modal-footer" id="dialog.footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
    var _server = '<?php echo Config::get('URL'); ?>';
    var user_id = <?php echo Session::get("user_id"); ?>;
    var user_category = <?php echo Session::get("user_account_type");?>;
</script>
<?php if (Session::get('user_account_type') > 1) { ?>
    <script src="js/app.js"></script>
    <script src="js/global.js"></script>
<?php } else { ?>
    <script type="module" src="js/semana.js"></script>
<?php } ?>