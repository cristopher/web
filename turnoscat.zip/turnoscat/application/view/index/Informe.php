<h3 class="text-center">Calendario de Turnos Clinica Alemana Temuco, Mes <span id="meses"></span><br>Unidad o Departamento "<?php echo $this->departamento; ?>"</h3>
<p>&nbsp;</p>
<table class="table table-bordered table-hover">
    <thead class="bg-light">
        <tr id="primera.cabecera">
            <th class="text-secondary text-center" id="primera.cabecera.primera.columna">Días / Fecha</th>
            <th class="text-secondary text-center" id="primera.cabecera.segunda.columna">Turnos programados<br>según rotativa estándar<br>de la unidad o departamento</th>
            <th class="text-secondary text-center" id="primera.cabecera.tercera.columna">Turnos efectivamente realizados por médicos de la unidad o departamento</th>
        </tr>
        <tr id="segunda.cabecera" class="d-none">
            <th class="text-secondary text-center" id="segunda.cabecera.primera.columna">Turno Diurno</th>
            <th class="text-secondary text-center" id="segunda.cabecera.segunda.columna">Turno Nocturno</th>
        </tr>
                <tr id="tercera.cabecera" class="d-none">
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                </tr>
            </thead>
    <tbody id="table.calendario">
        <tr>
            <td colspan="6" class="text-center text-danger">Cargando...</td>
        </tr>
    </tbody>
</table>
<p>&nbsp;</p>
<div class="row">
    <div class="col px-5">
        <p class="mb-0 text-center" id="fecha"></p>
        <hr>
        <p class="text-center">Fecha</p>
    </div>
    <div class="col px-5">
        <p class="mb-0 text-center"><?php echo $this->jefe; ?></p>
        <hr>
        <p class="text-center">V° B° Jefe Unidad</p>
    </div>
</div>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
    var month = '<?php echo $this->mes; ?>';
    var year = '<?php echo $this->año; ?>';
    var departament = "<?php echo $this->departament; ?>";
    var category = "<?php echo $this->categoria; ?>";
    var user_id = '<?php echo Session::get("user_id"); ?>'
</script>
<script src="js/informe.js"></script>