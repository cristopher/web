<h4 class="text-center">Calendario de Turnos Médico <span id="turnosTit"></span> Clinica Alemana Temuco, Mes <span id="meses"></span><br>Unidad o Departamento "<?php echo $this->departamento; ?>"</h4>
<p>&nbsp;</p>
<table class="table table-bordered table-hover">
    <thead class="bg-light">
    <tr id="primera.cabecera">
                    <th class="text-secondary text-center" id="primera.cabecera.primera.columna">Días / Fecha</th>
                    <th class="text-secondary text-center" id="primera.cabecera.segunda.columna">Turnos programados<br>según rotativa estándar<br>de la unidad o departamento</th>
                    <th class="text-secondary text-center" id="primera.cabecera.tercera.columna">Turnos efectivamente realizados por médicos de la unidad o departamento</th>
                </tr>
                <tr id="segunda.cabecera" class="d-none">
                    <th class="text-secondary text-center" id="segunda.cabecera.primera.columna">Turno Diurno</th>
                    <th class="text-secondary text-center" id="segunda.cabecera.segunda.columna">Turno Nocturno</th>
                </tr>
    <tr class="bg-light d-none" id="table.diurno.extra">
        <th class="text-secondary text-center d-none" scope="col" id="table.diurno.residente">Médico titular</th>
        <th class="text-secondary text-center d-none" scope="col" id="table.diurno.refuerzo">Médico de refuerzo</th>
        <th class="text-secondary text-center d-none" scope="col" id="table.nocturno.residente">Médico titular</th>
        <th class="text-secondary text-center d-none" scope="col" id="table.nocturno.refuerzo">Médico de refuerzo</th>
    </tr>
    </thead>
    <tbody id="table.calendario">
        <tr>
            <td colspan="6" class="text-center text-danger">Cargando...</td>
        </tr>
    </tbody>
</table>
<p>&nbsp;</p>
<div class="row">
    <div class="col px-5">
        <p class="mb-0 text-center" id="fecha"></p>
        <hr>
        <p class="text-center">Fecha</p>
    </div>
    <div class="col px-5">
        <p class="mb-0 text-center"><?php echo $this->jefe; ?></p>
        <hr>
        <p class="text-center">V° B° Jefe Unidad</p>
    </div>
</div>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
    var month = '<?php echo $this->mes; ?>';
    var year = '<?php echo $this->año; ?>';
    var departament = "<?php echo $this->departament; ?>";
    var user_id = '<?php echo Session::get("user_id"); ?>'
    var par = "<?php echo $this->par; ?>";
</script>
<script src="js/columnas.js"></script>