<div class="container my-1">
    <h4 class="text-center">Resumen horas médicas de turnos realizadas según departamento</h4>
    <div class="card">
        <div class="card-body p-2">
            <div class="form-row">
                <div class="col-12 col-sm-4">
                    <div class="form-group">
                        <label for="departamentos.header">Elegir departamento o unidad</label>
                        <select id="departamentos.header" class="form-control"><option value="0">Cargando....</option></select>
                    </div>
                </div>
                <div class="col-6 col-sm-3">
                    <div class="form-group">
                        <label for="fecha.uno">Desde</label>
                        <input id="fecha.uno" class="form-control" type="date">
                    </div>
                </div>
                <div class="col-6 col-sm-3">
                    <div class="form-group">
                        <label for="fecha.dos">Hasta</label>
                        <input id="fecha.dos" class="form-control" type="date">
                    </div>
                </div>
                <div class="col-6 col-sm-2 p-1">
                <button type="button" class="btn btn-secondary my-4" id="horas.imprimir">Imprimir</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead class="bg-light">
                <tr id="primera.cabecera">
                    <th class="text-secondary">Profesionales en turno</th>
                    <th class="text-secondary">Horas Médico Titular</th>
                    <th class="text-secondary">Horas Médico Refuerzo</th>
                </tr>
            </thead>
            <tbody id="table.horas">
            <tr>
                <td colspan="3" class="text-center text-danger">Cargando...</td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
</script>
<script src="js/turnos_horas.js"></script>