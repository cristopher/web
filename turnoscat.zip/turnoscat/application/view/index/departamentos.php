<h3 class="text-center">Resumen horas realizadas por departamento</h3>
<div class="container my-1">
    <h4 class="text-center">Resumen horas médicas de turnos realizadas según departamento</h4>
    <div class="card">
        <div class="card-body p-2">
            <div class="form-row">
                <div class="col-6 col-sm-5">
                    <div class="form-group">
                        <label for="fecha.uno">Desde</label>
                        <input id="fecha.uno" class="form-control" type="date">
                    </div>
                </div>
                <div class="col-6 col-sm-5">
                    <div class="form-group">
                        <label for="fecha.dos">Hasta</label>
                        <input id="fecha.dos" class="form-control" type="date">
                    </div>
                </div>
                <div class="col-6 col-sm-2 p-1">
                <button type="button" class="btn btn-secondary my-4" id="horas.imprimir">Imprimir</button>
                </div>
            </div>
        </div>
    </div>
</div>
<table class="table table-bordered table-hover">
    <thead class="bg-light">
        <tr>
            <th class="text-secondary text-center" scope="col">Departamento</th>
            <th class="text-secondary text-center" scope="col">Número de horas médico titular</th>
            <th class="text-secondary text-center" scope="col">Valor total titular</th>
            <th class="text-secondary text-center" scope="col">Número de horas médico refuerzo</th>
            <th class="text-secondary text-center" scope="col">Valor total refuerzo</th>
            <th class="text-secondary text-center" scope="col">Total general</th>
        </tr>
    </thead>
    <tbody id="table.calendario">
        <tr>
            <td colspan="3" class="text-center text-danger">Cargando...</td>
        </tr>
    </tbody>
</table>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
</script>
<script src="js/informe.departamentos.js"></script>