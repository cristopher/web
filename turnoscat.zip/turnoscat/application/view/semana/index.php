<header class="py-4 wetrust sticky-top">
    <div class="container">
        <h2 class="mt-2">Reporte 7 días</h2>
        <div class="row">
            <div class="col-6 form-group">
                <label>Seleccione departamento</label>
                <select class="form-control" id="departamento">
                </select>
            </div>
            <div class="col-3 form-group">
                <label>Fecha Inicial</label>
                <input class="form-control" type="date" id="fecha.inicial">
            </div>
            <div class="col-3 form-group">
                <label>Fecha Final</label>
                <input class="form-control" type="date" id="fecha.final">
            </div>
        </div>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <table class="table table-bordered table-hover shadow">
            <thead class="bg-light">
                <tr id="primera.cabecera">
                    <th class="text-secondary text-center" id="primera.cabecera.primera.columna">Días</th>
                    <th class="text-secondary text-center" id="primera.cabecera.segunda.columna">Turnos asignados rotativa estándar</th>
                    <th class="text-secondary text-center" id="primera.cabecera.tercera.columna">Turnos efectivamente realizados</th>
                </tr>
                <tr id="segunda.cabecera" class="d-none">
                    <th class="text-secondary text-center d-none" id="segunda.cabecera.primera.columna">Médico</th>
                    <th class="text-secondary text-center d-none" id="segunda.cabecera.segunda.columna">Distribución Horaria</th>
                    <th class="text-secondary text-center" id="segunda.cabecera.tercera.columna">Turno Diurno</th>
                    <th class="text-secondary text-center" id="segunda.cabecera.cuarta.columna">Turno Nocturno</th>
                </tr>
                <tr id="tercera.cabecera" class="d-none">
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                    <th class="text-secondary text-center" scope="col">Médico titular</th>
                    <th class="text-secondary text-center" scope="col">Médico de refuerzo</th>
                </tr>
            </thead>
            <tbody id="table.calendario">
                <tr><td colspan="6" class="text-center text-danger">Cargando...</td></tr>
            </tbody>
        </table>
    </div>
</main>
<script>
    var _api = '<?php echo Config::get('URL'); ?>api';
    var _server = '<?php echo Config::get('URL'); ?>';
    var user_id = <?php echo Session::get("user_id"); ?>;
    var user_category = <?php echo Session::get("user_account_type");?>;
</script>
<script src="js/semana_admin.js"></script>