<section>
    <header class="py-4 wetrust">
        <div class="container">
            <h1>Cambiar Telefono</h1>
        </div>
    </header>
    <main class="py-4 minimo">
        <div class="container">
            <?php $this->renderFeedbackMessages(); ?>
            <div class="d-flex justify-content-center">
                <div class="card shadow">
                    <div class="card-body">
                        <form method="post" action="<?php echo Config::get('URL'); ?>user/changePhone_action" name="new_phone_form">
                            <div class="form-group">
                                <label>Ingrese la contraseña que actualmente tiene:</label>
                                <input type="number" class="form-control" name='user_phone' pattern=".{10,}" required autocomplete="off">
                            </div>
                            <button type="submit" class="btn btn-outline-danger my-4 shadow-lg mx-auto d-block">Cambiar teléfono</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
</section>