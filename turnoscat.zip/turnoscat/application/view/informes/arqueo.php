<link rel="stylesheet" href="js/datetime/default.css">
<link rel="stylesheet" href="js/datetime/default.date.css">
<script src="js/datetime/picker.js"></script>
<script src="js/datetime/picker.date.js"></script>
<script src="js/datetime/es_ES.js"></script>

<header class="py-4 wetrust sticky-top">
    <div class="container">
        <div class="d-flex justify-content-start align-items-center">
            <a class="h1 mr-2" href="<?= Config::get('URL'); ?>"><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-arrow-left-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/><path fill-rule="evenodd" d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z"/></svg></a>
            <h1 class="mb-0">Resumen por unidades</h1>
        </div>
        <div class="row mt-2">
            <div class="col-3 form-group">
                <label>Fecha Inicial</label>
                <input class="form-control" type="date" id="fecha.inicial" name="fecha_inicial" value="<?= $this->fecha_ini; ?>">
            </div>
            <div class="col-3 form-group">
                <label>Fecha Final</label>
                <input class="form-control" type="date" id="fecha.final" name="fecha_final" value="<?= $this->fecha_fin; ?>">
            </div>
        </div>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <div class="card shadow">
            <div class="card-body">
                <table class="table table-hover rounded shadow">
                    <thead class="bg-light shadow">
                        <tr id="primera.cabecera" class="shadow">
                            <th class="text-secondary text-center">Unidad &#47; Departamento</th>
                            <th class="text-secondary text-center">Turnos Titulares</th>
                            <th class="text-secondary text-center">Horas Titular</th>
                            <th class="text-secondary text-center">Turnos Refuerzos</th>
                            <th class="text-secondary text-center">Horas Refuerzo</th>
                            <th class="text-secondary text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody id="table.calendario">
                        <tr><td colspan="6" class="text-center text-danger">Cargando...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<script>
    var fecha_ini = "<?= $this->fecha_ini; ?>"
    var fecha_fin = "<?= $this->fecha_fin; ?>"

    $(document).ready(function(){
        $("#fecha\\.inicial").on("change", function(){
            fecha_ini = this.value
            getData()
        })

        $("#fecha\\.final").on("change", function(){
            fecha_fin = this.value
            getData()
        })

        if (safari() == true) {
            $("#fecha\\.inicial").addClass("datepicker").pickadate();
            $("#fecha\\.final").addClass("datepicker").pickadate()
        }

        getData()
    })

    function getData(){
        let data = new FormData()
        if (safari() == true) {
            data.append("fecha_inicio", $("input[name='fecha_inicial_submit']").val())
            data.append("fecha_final", $("input[name='fecha_final_submit']").val())
        } else {
            data.append("fecha_inicio", fecha_ini)
            data.append("fecha_final", fecha_fin)
        }

        $("#table\\.calendario").empty();

        fetch('informes/arqueo_json', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
        .then(data => {

            var total_titular = 0
            var total_refuerzo = 0
            var total_h_titular = 0
            var total_h_refuerzo= 0

            for (let H = 0; H <= (data.length -1); H++){
                let h_titular = (data[H].horas_titular == null) ? 0 : +data[H].horas_titular
                let h_refuerzo = (data[H].horas_refuerzo == null) ? 0 : +data[H].horas_refuerzo

                let fila = '<tr><td>'+data[H].departamento_name+'</td><td>$ '+dinero(data[H].departamento_titular)+'</td><td>'+h_titular+' horas</td><td>$ '+dinero(data[H].departamento_refuerzo)+'</td><td>'+h_refuerzo+' horas</td><td class="bg-light">$ '+dinero((+data[H].departamento_titular)+(+data[H].departamento_refuerzo))+'</td></tr>'

                total_titular += +data[H].departamento_titular
                total_refuerzo += +data[H].departamento_refuerzo
                total_h_titular += h_titular
                total_h_refuerzo += h_refuerzo
                $("#table\\.calendario").append(fila);
            }

            let fila = '<tr class="bg-light"><td><strong>Total</strong></td><td>$ '+dinero(total_titular)+'</td><td>'+ total_h_titular+' horas</td><td>$ '+dinero(total_refuerzo)+'</td><td>'+ total_h_refuerzo+' horas</td><td><strong>$ '+dinero(total_titular+total_refuerzo)+'</strong></td></tr>'
            $("#table\\.calendario").append(fila);
        })
    }

    function dinero(num){
        if(!isNaN(num)){
            num = num.toString().split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,'$1.');
            num = num.split('').reverse().join('').replace(/^[\.]/,'');
            return num;
        }else{
            return num.replace(/[^\d\.]*/g,'');
        }
    }

    function safari(){
        //solo si es safari en computador
        //safari en el celular si tiene soporte de calendario

        let agent = navigator.userAgent
        agent = agent.toLowerCase()

        let find = agent.search(/safari/i);

        if (find != -1){
            let mobile = agent.search(/mobile/i)
            let windows = agent.search(/windows/i)

            if (mobile == -1 && windows == -1){
                return true
            }
        }

        return false
    }
</script>