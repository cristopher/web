<header class="py-4 wetrust">
    <div class="container">
        <h1>Planilla de turnos</h1>
    </div>
</header>
<main class="minimo">
    <div class="container py-3">
        <?php $this->renderFeedbackMessages(); ?>
        <div class="card shadow">
            <div class="card-body">
                <div class="row">
                    <div class="form-group col-4">
                        <label for="departamentos">Elegir departamento o unidad</label>
                        <select class="form-control" id="departamentos">
                        </select>
                    </div>
                    <div class="form-group col-4">
                        <label>Médico</label>
                        <select class="form-control" id="cambiar.turno.asignado">
                            <option value="0">Médico Titular</option>
                            <option value="5">Médico Refuerzo</option>
                            <option value="7" selected>Todos</option>
                        </select>
                    </div>
                    <div class="form-group col-4">
                        <label>Mes</label>
                        <select class="form-control" id="mes">
                            <option value="01">Enero</option>
                            <option value="02">Febrero</option>
                            <option value="03">Marzo</option>
                            <option value="04">Abril</option>
                            <option value="05">Mayo</option>
                            <option value="06">Junio</option>
                            <option value="07">Julio</option>
                            <option value="08">Agosto</option>
                            <option value="09">Septiembre</option>
                            <option value="10">Octubre</option>
                            <option value="11">Noviembre</option>
                            <option value="12">Diciembre</option>
                        </select>
                    </div>
                    <div class="form-group col-4">
                        <label>Semana</label>
                        <select class="form-control" id="semana"></select>
                    </div>
                    <div class="form-group col-12">
                        <button class="btn btn-info" id="preparar" data-toggle="modal" data-target="#reporte">Preparar reporte para impresion</button>
                    </div>
                <div>
            <div>
        <div>
    </div>
</main>
<div class="modal" tabindex="-1" id="reporte">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header wetrust">
        <h5 class="modal-title mx-auto">Preparar informe</h5>
      </div>
      <div class="modal-body" id="modal.body">
        <p class="text-center">Preparando su informe</p>
        <div class="d-flex justify-content-center">
            <div class="spinner-border text-info" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
      </div>
      <div class="modal-footer" id="modal.footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<script>
let now = new Date();
let month = ("0" + (now.getUTCMonth() + 1)).slice(-2);

var _api = '<?php echo Config::get('URL'); ?>api';
var year = now.getUTCFullYear();
var mes = ("0" + (now.getUTCMonth() + 1)).slice(-2);
var dias = ""
var mesEsp = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

$(document).ready(function(){
    departamentos();

    $("#mes").on("change",function(){
        calcularSemanas(this.value);
        mes = this.value
    }).val(mes)
    
    calcularSemanas(mes)
    $("#preparar").on("click", function(){
        let semana = $("#semana").val();
        let medico = $("#cambiar\\.turno\\.asignado").val();

        let data = new FormData()
        data.append("accion", "semana")
        data.append("departamento", $("#departamentos").val())
        data.append("mes", mes)
        data.append("ano", year)
        data.append("semana", semana)
        data.append("medico", medico)

            fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
            .then(data => {
                if (Object.keys(data).length > 0) {
                    matrizProf = [];
                    let medico = $("#cambiar\\.turno\\.asignado").val();

                    $("#modal\\.body").html('<div class="d-flex justify-content-center"><input id="tipoturno" type="hidden" value=""><div class="d-none" id="imprimir.semanas"></div><button type="button" class="btn btn-info" id="dialog.finalprint">Ver Impresion</button></div>');
                    
                    $("#imprimir\\.semanas").html('<table class="table table-hover table-bordered"><thead class="bg-light" id="table.imprimir.semanas.head"></thead><tbody id="table.imprimir.semanas"></tbody></table>');

                    if (medico == 0){
                        $("#tipoturno").val("titulares");
                    } else if (medico == 5){
                        $("#tipoturno").val("refuerzos");
                    } else {
                        $("#tipoturno").val("Rotativa");
                    }
                    
                    let contadorfilas = 0;
                    $.each(data.data, function(i, val){
                        if (matrizProf.includes(val.user_name) == false){ 
                            matrizProf.push(val.user_name); 
                            contadorfilas++
                        }
                    });

                    $.each(matrizProf, function(i, val){
                        const turnos = filtrarTurnos(data.data, val);
                        var fila = '<tr><td>'+ val +'</td>';

                        for (let i = 0; i <= 6; i++){
                            
                            let _f_ini = new Date(data.fecha_ini);
                            _f_ini.setDate(_f_ini.getDate() + i);

                            let dia = ("0" + _f_ini.getUTCDate()).slice(-2);
                            let mes = ("0" + (_f_ini.getUTCMonth()+1)).slice(-2);
                            let año = _f_ini.getUTCFullYear();

                            let lafecha = año + "-" + mes + "-" + dia;
                            let filtros = filtrarFecha(turnos, lafecha);

                            fila += (Object.keys(filtros).length > 0) ? '<td class="gris"></td>' : '<td></td>';
                        }

                        fila += '<td></td></tr>';
                        $("#table\\.imprimir\\.semanas").append(fila);
                    });

                    //añadir 6 filas más vacias
                    for (let i = contadorfilas; i <= 12; i++){
                        let vacio = '<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
                        $("#table\\.imprimir\\.semanas").append(vacio);
                    }

                    vacio = '<tr><td>Total hrs. del día</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
                    $("#table\\.imprimir\\.semanas").append(vacio);

                    let tableHeader = '<tr><th scope="col"><span class="h6">Profesionales<br>asignados</span></th>';
                    let dias = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

                    for (let i = 0; i <= 6; i++){
                        let _f_ini = new Date(data.fecha_ini);
                        _f_ini.setDate(_f_ini.getDate() + i);

                        let dia = ("0" + _f_ini.getUTCDate()).slice(-2);
                        tableHeader += '<th scope="col" class="text-center">'+ dias[i]+ '<br>'+ dia + '</th>';
                    }

                    tableHeader += '<th scope="col">Total Semana</th><tr>';

                    $("#table\\.imprimir\\.semanas\\.head").append(tableHeader);

                    $("#dialog\\.finalprint").on("click", function(){
                        var documento = '<!doctype html><html lang="es"><head> <meta charset="utf-8"> <meta name="viewport" content="user-scalable=no,maximum-scale=1, minimum-scale=1, width=device-width, initial-scale=1, shrink-to-fit=no"> <title>Turnos</title> <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> <style>@media print{@page{size: landscape}.table td, .table th{padding: 0.32rem !important}.gris{background-color: #DDD !important; box-shadow: inset 0 0 0 1000px #DDD !important; -webkit-print-color-adjust: exact;}}.table td, .table th{padding: 0.32rem !important}.gris{background-color: #DDD !important; box-shadow: inset 0 0 0 1000px #DDD !important; -webkit-print-color-adjust: exact;}</style></head><body class="mb-0 pb-0"> <h5 class="mt-0 pt-0">Propuesta de turnos :CATEGORIATURNOS, departamento: :DEPARTAMENTO , :MESANO</h5>:TABLA <p>&nbsp;</p><div class="row mt-4"> <div class="col px-5"> <hr> <p class="text-center">V° B° Coord. Unidad</p></div><div class="col px-5"> <hr> <p class="text-center">V° B° Jefe Departamento</p></div></div><p style="font-size: 70%;"><u>Estimado Doctor(a): En la casilla correspondiente a su nombre y fecha, favor indicar horario de turno realizado y firma. En caso que no esté en nómina incorporar su nombre en las casillas vacías.</u></p><script>document.addEventListener("DOMContentLoaded", function(event){var ventimp=window; ventimp.print(); ventimp.close()}); <\/script></body></html>';
                        var element = document.getElementById("imprimir.semanas");
                        var calendario = element.outerHTML;
                        calendario = calendario.replace('d-none', '');
                        documento = documento.replace(':MESANO', mesEsp[parseInt(mes)-1] + " " + year);
                        documento = documento.replace(':TABLA', calendario);
                        var tipoprofesional = $("#tipoturno").val();
                        documento = documento.replace(':CATEGORIATURNOS', tipoprofesional);
                        documento = documento.replace(':DEPARTAMENTO', '&nbsp;&nbsp;&nbsp;' + $("#departamentos option:selected").text());
                        var ventimp = window.open(' ', 'popimpr');
                        ventimp.document.write(documento);
                        ventimp.document.close();
                    });
                }
            });
        });
})

function calcularSemanas(mes){
    mes = parseInt(mes)-1; //los meses son de 0 a 11 para javascript
    var primerdia = ((new Date(year, mes, 1).getDay()-1)%7+7)%7;
    var dias=new Date(year, mes+1,0).getDate()-7+primerdia;
    let semanas = Math.ceil(dias/7)+1;
    let i = 1;
    $("#semana").empty()
    for (i; i <= semanas; i++){
        $("#semana").append('<option value="'+ i +'">Semana '+ i +'</option>');
    }

    mes = ("0" + (mes+1)).slice(-2); //los meses son de 01 a 12 para php
}

function departamentos(){
    let data = new FormData()

    data.append("accion", "departamentos")

    fetch(_api + '/get', {method: 'POST',body: data, mode: 'cors'}).then(response => response.json())
    .then(data => {

        $("#departamentos").empty();

        if (Object.keys(data).length > 0) {
            $.each(data, function(i, item) {
                let option = '<option value="' + item.departamento_id + '" data-categoria="' + item.departamento_categoria + '" data-jefe="' + item.departamento_eljefe + '" data-hora-asignada="' + item.departamento_horas_asignadas + '" data-hora-asignada-refuerzo="'+ item.departamento_horas_asignadas_refuerzo+'" data-hora-realizada="' + item.departamento_horas_realizadas + '" data-hora-refuerzo="' + item.departamento_horas_refuerzo + '" data-comentario="' + item.departamento_comentarios + '" data-jornada="'+item.departamento_jornada+'">' + item.departamento_name + '</option>';
                $("#departamentos").append(option);
            });
        }

    }).catch(function(error) {
        alert("error")
    });
}

function filtrarTurnos(data, nombre){

let filtro = data.filter(turno => {
    return turno.user_name === nombre;
});

return filtro;
}

function filtrarFecha(data, fecha){

let filtro = data.filter(turno => {
    return turno.turno_fecha === fecha;
});

return filtro;
}

function diasEnUnMes(mes, año) {
return new Date(año, mes, 0).getDate();
}
</script>