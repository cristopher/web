<?php

class IndexController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        Auth::checkAuthentication();
    }

    public function index()
    {
        $this->View->render('index/index',array(
            'title' => 'Turnos'
        ));
    }

    public function informe($mes, $año, $departament)  //no operativo
    {
        $departamento = DepartamentosModel::getDepartamento($departament);
        $this->View->render('index/Informe', array(
            'mes' => $mes,
            'año' => $año,
            'departament' => $departament,
            'departamento' => $departamento->departamento_name,
            'jefe' => $departamento->user_nombre,
            'categoria' => $departamento->departamento_categoria,
            'title' => 'Informe'
        ));
    }

    public function columnas($mes, $año, $departament, $par)  //no operativo
    {
        $departamento = DepartamentosModel::getDepartamento($departament);
        $this->View->render('index/columnas', array(
            'mes' => $mes,
            'año' => $año,
            'par' => $par,
            'departament' => $departament,
            'departamento' => $departamento->departamento_name,
            'jefe' => $departamento->user_nombre,
            'title' => 'Columnas'
        ));
    }

    public function horas() //no operativo
    {
        $this->View->render('index/informehoras',array(
            'title' => 'Informe Horas'
        ));
    }

    public function departamentos() //no operativo
    {
        $this->View->render('index/departamentos',array(
            'title' => 'Informe departamento'
        ));
    }

    public function usuarios($departamento_id) //
    {
        $this->View->render('index/usuarios', array(
            'departamento' => DepartamentosModel::getDepartamento($departamento_id),
            'usuarios' => ProfesionalesModel::getProfesionales($departamento_id),
            'title' => 'Usuarios'
        ));
    }
}
