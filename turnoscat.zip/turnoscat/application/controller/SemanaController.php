<?php

class SemanaController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        Auth::checkAuthentication();
    }

    public function index()
    {
        $this->View->render('semana/index',array(
            'title' => 'Reporte 7 días'
        ));
    }

    public function dos()
    {
        $this->View->render('semana/dos',array(
            'title' => 'Reporte 7 días'
        ));
    }
}
