<?php

class ApiController extends Controller {
    /**
     * Construct this object by extending the basic Controller class
     */
    public function __construct(){
        parent::__construct();
        Auth::checkAuthentication();
    }

    public function sw($apikey = NULL, $dato = NULL){
        $resultado = new stdClass();
        $resultado->response = true;

        if (!$apikey || strlen($apikey) == 0){
            $resultado->response = false;
            $resultado->response = "¿Que intentas hacer humano?";
            return $this->View->renderJSON($resultado);
        }

        switch ($dato){
            case "profesionales":
                break;
            case "departamentos":
                break;
            default:
                $resultado->response = false;
                $resultado->data = "¿Cuál es tu problema humano?";
        }

        return $this->View->renderJSON($resultado);
    }

    public function get(){
        $accion = Request::post('accion');
        $resultado = "";

        switch ($accion) {
            case "calendario":
                $resultado = TurnosModel::getAllTurnos(Request::post('departamento'), Request::post('mes'),Request::post('ano'));
                break;
            case "departamentos":
                $resultado = DepartamentosModel::getAllDepartamentos(); //
                break;
            case "departamento":
                $resultado = DepartamentosModel::getDepartamento(Request::post('departamento'));
                break;
            case "profesionales":
                $resultado = ProfesionalesModel::getProfesionales(Request::post('departamento'));
                break;
            case "profesionalesAll":
                $resultado = ProfesionalesModel::getAllProfesionales(Request::post('departamento'));
                break;
            case "turno":
                $resultado = TurnosModel::getTurno(Request::post('departamento'),Request::post('fecha'),Request::post('categoria'));
                break;
            case "turno_dias":
                $resultado = TurnosModel::getSevenTurnos(Request::post('departamento'), Request::post('fecha'));
                break;
            case "jefes":
                $resultado = ProfesionalesModel::getJefes();//
                break;
            case "horas":
                $resultado = TurnosModel::getTurnoHoras(Request::post('departamento'), Request::post('fechauno'), Request::post('fechados'));
                break;
            case "hpersonas":
                $resultado = new stdClass();
                $resultado->titular = TurnosModel::getTurnoHorasPersonaTitular(Request::post('departamento'), Request::post('mes'), Request::post('ano'), Request::post('profesional'));
                $resultado->refuerzo = TurnosModel::getTurnoHorasPersonaRefuerzo(Request::post('departamento'), Request::post('mes'), Request::post('ano'), Request::post('profesional'));
                break;
            case "hpersonasrange":
                $resultado = new stdClass();
                $resultado->titular = TurnosModel::getTurnoHorasPersonaTitularFecha(Request::post('departamento'), Request::post('fecha_uno'), Request::post('fecha_dos'), Request::post('profesional'));
                $resultado->refuerzo = TurnosModel::getTurnoHorasPersonaRefuerzoFecha(Request::post('departamento'), Request::post('fecha_uno'), Request::post('fecha_dos'), Request::post('profesional'));
                break;
            case "semana":
                $resultado = TurnosModel::simpleCalendar(Request::post('departamento'), Request::post('mes'), Request::post('ano'), Request::post('semana'), Request::post('medico'));
                break;
            case "horasdpto":
                $resultado = TurnosModel::resumenHoras(Request::post('fechauno'), Request::post('fechados'));
                break;
            case "turno_filter":
                $resultado = TurnosModel::getFilter(Request::post('departamento'), Request::post('fecha_inicial'), Request::post('fecha_final'));
                break;
            case "profesionales_con_turno":
                $resultado = ProfesionalesModel::getProfesionalesTrabajando(Request::post('departamento'), Request::post('fecha_inicial'), Request::post('fecha_final'));
                break;     
        }

        return $this->View->renderJSON($resultado);

    }

    public function set(){
        $accion = Request::post('accion');
        $resultado = "";

        switch ($accion) {
            case "turno":
                $resultado = TurnosModel::createTurno(Request::post('fecha'),Request::post('profesional'),Request::post('categoria'),Request::post('horas'), Request::post('departamento'));
                break;
            case "cambiar":
                $resultado = TurnosModel::updateTurno(Request::post('turno_id'),Request::post('turno_profesional'));
                break;
            case "actualizar":
                $resultado = TurnosModel::updateTurnoHora(Request::post('turno_id'),Request::post('turno_horas'));
                break;
            case "departamentos": //
                $resultado = DepartamentosModel::createDepartamento(Request::post('id'),Request::post('nombre'),Request::post('jefe'),Request::post('categoria'),Request::post('valor_titular'),Request::post('valor_refuerzo'),Request::post('hora_turnos'),Request::post('hora_refuerzos'),Request::post('hora_jornada'), Request::post('horas_asignadas'), Request::post('horas_asignadas_refuerzo'), Request::post('comentario'));
                break;
            case "profesionales": //
                $resultado = ProfesionalesModel::createProfesionales(Request::post('departamento_id'),Request::post('profesional_id'));
                break;
            case "usuarios":
                $resultado = UserRoleModel::changeUserRole(Request::post('usuario_id'), Request::post('usuario_nivel'));
                break;
            case "comentario":
                $resultado = TurnosModel::createComentario(Request::post('turno_id'),Request::post('fecha'),Request::post('categoria'),Request::post('comentario'), Request::post('departamento'));
                break;
        }
        return $this->View->renderJSON($resultado);
    }

    public function delete(){
        $accion = Request::post('accion');
        $resultado = "";

        switch ($accion) {
            case "turno":
                $resultado = TurnosModel::deleteTurno(Request::post('turno_id'));
                break;
            case "departamentos": //
                $resultado = DepartamentosModel::deleteDepartamento(Request::post('departamento_id'));
                break;
            case "profesionales": //
                $resultado = ProfesionalesModel::deleteProfesional(Request::post('profesional_id'),Request::post('departamento_id'));
                break;
        }
        return $this->View->renderJSON($resultado);
    }
}