<?php

class InformesController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        Auth::checkAuthentication();
    }

    public function semana()
    {
        $this->View->render('informes/semana', array(
            'title' => 'Planilla de turnos'
        ));
    }

    public function arqueo()
    {
        $this->View->render('informes/arqueo', array(
            'fecha_ini' => TurnosModel::_data_first_month_day(),
            'fecha_fin' => TurnosModel::_data_last_month_day(),
            'title' => 'Arqueo de caja'
        ));
    }

    public function arqueo_json()
    {
        $this->View->renderJSON(TurnosModel::arqueo(Request::post("fecha_inicio"),Request::post("fecha_final")));
    }
}
