<?php

class ConfiguracionController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        Auth::checkAuthentication();

        if (Session::get("user_account_type") < 6) {

            Session::destroy();
            header('location: ' . Config::get('URL') . 'login');
            exit();
        }
    }

    public function index()
    {
        $this->View->render('configuracion/index',array(
            'title' => 'Configuracion'
        ));
    }
}
