<?php

class DepartamentosModel
{
    public static function getAllDepartamentos()
    {
        $database = DatabaseFactory::getFactory()->getConnection();
        $query = '';
        if (Session::get("user_account_type") > 5 || Session::get("user_account_type") == 1){
            $sql = "SELECT * FROM departamentos";
            $query = $database->prepare($sql);
            $query->execute();
            $query = $query->fetchAll();
        }
        else{
            //obtener el departamento del profesional
            $query = self::getDepartamentosWhereProfesional(Session::get("user_id"));
            $result = [];

            foreach($query as $key => $value) {
                array_push($result,self::getDepartamento($value->departamento_id));
            }
            $query = $result;
        }

        $contador = 0;
        $all_users_profiles = [];

        foreach ($query as $departamento) {

            array_walk_recursive($departamento, 'Filter::XSSFilter');

            $all_users_profiles[$contador] = new stdClass();
            $all_users_profiles[$contador]->departamento_id = $departamento->departamento_id;
            $all_users_profiles[$contador]->departamento_name = $departamento->departamento_name;
            $all_users_profiles[$contador]->departamento_jefe = $departamento->departamento_jefe;
            $all_users_profiles[$contador]->departamento_categoria = $departamento->departamento_categoria;
            $all_users_profiles[$contador]->departamento_titular = $departamento->departamento_titular;
            $all_users_profiles[$contador]->departamento_refuerzo = $departamento->departamento_refuerzo;
            $all_users_profiles[$contador]->departamento_eljefe = ($departamento->departamento_jefe == Session::get("user_id")) ? true : false;
            $all_users_profiles[$contador]->departamento_horas_realizadas = $departamento->departamento_horas_realizadas;
            $all_users_profiles[$contador]->departamento_horas_refuerzo = $departamento->departamento_horas_refuerzo;
            $all_users_profiles[$contador]->departamento_jornada = $departamento->departamento_jornada;
            $all_users_profiles[$contador]->departamento_horas_asignadas = $departamento->departamento_horas_asignadas;
            $all_users_profiles[$contador]->departamento_horas_asignadas_refuerzo = $departamento->departamento_horas_asignadas_refuerzo;
            $all_users_profiles[$contador]->departamento_comentarios = $departamento->departamento_comentarios;
            $contador++;
        }

        return $all_users_profiles;

    }

    public static function getDepartamento($departamento_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT departamentos.departamento_id, departamentos.departamento_name, departamentos.departamento_jefe, departamentos.departamento_categoria, departamentos.departamento_titular, departamentos.departamento_refuerzo, users.user_name, departamentos.departamento_horas_realizadas, departamentos.departamento_horas_refuerzo, departamentos.departamento_jornada, departamentos.departamento_horas_asignadas, departamentos.departamento_horas_asignadas_refuerzo, departamentos.departamento_comentarios FROM departamentos INNER JOIN users ON departamentos.departamento_jefe = users.user_id WHERE departamento_id = :departamento_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento_id));

        return $query->fetch();
    }

    public static function getDepartamentosWhereProfesional($profesional_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT departamento_id FROM profesionales WHERE profesional_id = :profesional_id";
        $query = $database->prepare($sql);
        $query->execute(array(':profesional_id' => $profesional_id));

        return $query->fetchAll();
    }

    public static function createDepartamento($id, $nombre, $jefe, $categoria, $valor_titular, $valor_refuerzo, $departamento_horas_realizadas, $departamento_horas_refuerzo, $departamento_jornada, $departamento_horas_asignadas, $departamento_horas_asignadas_refuerzo, $departamento_comentarios)
    {
        if (!$nombre || strlen($nombre) == 0) {
            Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_CREATION_FAILED'));
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        if ($id >0){
            return self::updateDepartamento($id,$nombre, $jefe, $categoria,$valor_titular, $valor_refuerzo, $departamento_horas_realizadas, $departamento_horas_refuerzo, $departamento_jornada, $departamento_horas_asignadas, $departamento_horas_asignadas_refuerzo, $departamento_comentarios);
        }
        else{
            $sql = "INSERT INTO departamentos (departamento_name, departamento_jefe, departamento_categoria, departamento_titular, departamento_refuerzo, departamento_horas_realizadas, departamento_horas_refuerzo, departamento_jornada, departamento_horas_asignadas, departamento_horas_asignadas_refuerzo, departamento_comentarios) VALUES (:departamento_name, :departamento_jefe, :departamento_categoria, :departamento_titular, :departamento_refuerzo, :departamento_horas_realizadas, :departamento_horas_refuerzo, :departamento_jornada, :departamento_horas_asignadas, :departamento_horas_asignadas_refuerzo, :departamento_comentarios)";
        }
        
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_name' => $nombre, ':departamento_jefe' => $jefe, ':departamento_categoria' => $categoria, ':departamento_titular' => $valor_titular, ':departamento_refuerzo' => $valor_refuerzo, ':departamento_horas_realizadas' => $departamento_horas_realizadas, ':departamento_horas_refuerzo' => $departamento_horas_refuerzo, ':departamento_jornada' => $departamento_jornada, ':departamento_horas_asignadas' => $departamento_horas_asignadas, ':departamento_horas_asignadas_refuerzo' => $departamento_horas_asignadas_refuerzo, ':departamento_comentarios' => $departamento_comentarios));

        if ($query->rowCount() == 1) {
            return true;
        }

        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_CREATION_FAILED'));
        return false;
    }

    public static function updateDepartamento($id,$nombre, $jefe, $categoria, $valor_titular, $valor_refuerzo, $departamento_horas_realizadas, $departamento_horas_refuerzo, $departamento_jornada, $departamento_horas_asignadas, $departamento_horas_asignadas_refuerzo, $departamento_comentarios)
    {
        if (!$id || !$nombre) { return false; }

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "UPDATE departamentos SET departamento_name = :departamento_name, departamento_jefe = :departamento_jefe, departamento_categoria = :departamento_categoria, departamento_titular = :departamento_titular, departamento_refuerzo = :departamento_refuerzo, departamento_horas_realizadas = :departamento_horas_realizadas, departamento_horas_refuerzo = :departamento_horas_refuerzo, departamento_jornada  = :departamento_jornada, departamento_horas_asignadas = :departamento_horas_asignadas, departamento_horas_asignadas_refuerzo = :departamento_horas_asignadas_refuerzo, departamento_comentarios = :departamento_comentarios WHERE departamento_id = :departamento_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $id, ':departamento_name' => $nombre, ':departamento_jefe' => $jefe, ':departamento_categoria' => $categoria, ':departamento_titular' => $valor_titular, ':departamento_refuerzo' => $valor_refuerzo, ':departamento_horas_realizadas' => $departamento_horas_realizadas, ':departamento_horas_refuerzo' => $departamento_horas_refuerzo, ':departamento_jornada' => $departamento_jornada, ':departamento_horas_asignadas' => $departamento_horas_asignadas, ':departamento_horas_asignadas_refuerzo' => $departamento_horas_asignadas_refuerzo, ':departamento_comentarios' => $departamento_comentarios));

        if ($query->rowCount() == 1) {
            return true;
        }

        return false;
    }

    public static function deleteDepartamento($departamento_id)
    {
        if (!$departamento_id) {
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "DELETE FROM departamentos WHERE departamento_id = :departamento_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento_id));

        if ($query->rowCount() == 1) {
            return true;
        }

        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_DELETION_FAILED'));
        return false;
    }
}
