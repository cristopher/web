<?php

class ProfesionalesModel
{
    public static function getProfesionales($departamento_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT profesionales.profesional_id, users.user_name, users.user_phone, users.user_email FROM profesionales INNER JOIN users ON profesionales.profesional_id = users.user_id WHERE profesionales.departamento_id = :departamanto_id ORDER BY users.user_name";
        $query = $database->prepare($sql);
        $query->execute(array(':departamanto_id' => $departamento_id));

        return $query->fetchAll();
    }

    //obtiene los profesionales que han hecho turno durante el mes
    public static function getProfesionalesTrabajando($departamento_id, $fechainic, $fechafin)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT profesionales.profesional_id, users.user_name, users.user_phone, users.user_email FROM profesionales INNER JOIN users ON profesionales.profesional_id = users.user_id WHERE profesionales.departamento_id = :departamanto_id AND profesionales.profesional_id IN (SELECT turno_profesional FROM turnos WHERE turno_fecha between :turno_fechainic AND :turno_fechafin GROUP BY turno_profesional) ORDER BY users.user_name";
        $query = $database->prepare($sql);
        $query->execute(array(':departamanto_id' => $departamento_id, ':turno_fechainic' => $fechainic, ':turno_fechafin' => $fechafin));

        return $query->fetchAll();
    }

    public static function getProfesional($departamento_id,$profesional_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT profesional_id FROM profesionales WHERE departamento_id = :departamanto_id AND profesional_id = :profesional_id";
        $query = $database->prepare($sql);
        $query->execute(array(':departamanto_id' => $departamento_id,':profesional_id' => $profesional_id));

        if ($query->rowCount() == 1) {
            return true;
        }

        return false;
    }

    public static function createProfesionales($departamento_id,$profesional_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $exist = self::getProfesional($departamento_id,$profesional_id);

        if ($exist == false){
            $sql = "INSERT INTO profesionales (departamento_id, profesional_id) VALUES (:departamento_id, :profesional_id)";
        }
        else{
            $sql = "UPDATE profesionales SET departamento_id = :departamento_id, profesional_id = :profesional_id WHERE departamento_id = :departamento_id AND profesional_id = :profesional_id LIMIT 1";
        }

        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento_id,':profesional_id' => $profesional_id));

        if ($query->rowCount() == 1) {
            return true;
        }

        return false;
    }

    //
    public static function getAllProfesionales($departamento)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT user_id, user_name FROM users WHERE user_account_type in (2, 3) AND user_id NOT IN (SELECT profesional_id FROM profesionales WHERE profesionales.departamento_id = :departamento_id) ORDER BY user_name";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento));

        return $query->fetchAll();
    }

    public static function getJefes(){

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT user_id, user_name FROM users WHERE user_account_type = 3 ORDER BY user_name";
        $query = $database->prepare($sql);
        $query->execute();

        return $query->fetchAll();
    }

    public static function deleteProfesional($profesional_id,$departamento_id)
    {
        if (!$profesional_id) {
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "DELETE FROM profesionales WHERE departamento_id = :departamento_id AND profesional_id = :profesional_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento_id,':profesional_id' => $profesional_id));

        if ($query->rowCount() == 1) {
            return true;
        }

        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_DELETION_FAILED'));
        return false;
    }
}
