<?php

class TurnosModel
{
    public static function arqueo($fecha_inicio, $fecha_final)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT A.departamento_id, A.departamento_name, A.departamento_titular, B.departamento_titular as horas_titular, A.departamento_refuerzo, B.departamento_refuerzo as horas_refuerzo FROM ( SELECT departamentos.departamento_id, departamentos.departamento_name, SUM(departamentos.departamento_titular * turnos.turno_horas) as departamento_titular, SUM(departamentos.departamento_refuerzo * turnos.turno_horas) as departamento_refuerzo FROM turnos INNER JOIN departamentos ON turnos.turno_departamento = departamentos.departamento_id WHERE turnos.turno_categoria IN (1,2,3,4) AND turnos.turno_fecha between :fecha_inicio AND :fecha_final GROUP BY departamentos.departamento_id) AS A left JOIN ( SELECT A.departamento_id, A.departamento_titular, B.departamento_refuerzo FROM (SELECT turno_departamento as departamento_id, SUM(turno_horas) as departamento_titular FROM turnos WHERE turno_categoria IN (1,3) AND turno_fecha between :fecha_inicio AND :fecha_final group by turno_departamento) as A LEFT JOIN (SELECT turno_departamento as departamento_id, SUM(turno_horas) as departamento_refuerzo FROM turnos WHERE turno_categoria IN (2,4) AND turno_fecha between :fecha_inicio AND :fecha_final group by turno_departamento) as B ON A.departamento_id=B.departamento_id) AS B ON A.departamento_id=B.departamento_id";

        //$sql = "SELECT departamentos.departamento_id, departamentos.departamento_name, SUM(departamentos.departamento_titular * turnos.turno_horas) as departamento_titular, SUM(departamentos.departamento_refuerzo * turnos.turno_horas) as departamento_refuerzo FROM turnos INNER JOIN departamentos ON turnos.turno_departamento = departamentos.departamento_id WHERE turnos.turno_categoria IN (1,2,3,4) AND turnos.turno_fecha between :fecha_inicio AND :fecha_final GROUP BY departamentos.departamento_id";
        $query = $database->prepare($sql);
        $query->execute(array(':fecha_inicio' => $fecha_inicio, ':fecha_final' => $fecha_final));

        return $query->fetchAll();
    }

    public static function getAllTurnos($departamento, $mes, $año)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $fechainic = $año. "-".$mes."-01";
        
        $mesSiguiente = intval($mes) +1;

        if ($mesSiguiente == 13){
            $año = $año+1;
            $mesSiguiente = 1;
        }

        $mesSiguiente = "0".$mesSiguiente;
        $mesSiguiente = substr($mesSiguiente, -2); 

        $fechafin = $año. "-".$mesSiguiente."-01";
        
        $sql = "SELECT turnos.turno_fecha, turnos.turno_profesional, users.user_name, turnos.turno_categoria, turnos.turno_horas, turnos.turno_comentario FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turno_departamento = :turno_departamento AND turnos.turno_fecha between :turno_fechainic AND :turno_fechafin";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento, ':turno_fechainic' => $fechainic, ':turno_fechafin' => $fechafin));

        return $query->fetchAll();
    }

    public static function getSevenTurnos($departamento, $fecha)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $fecha = new DateTime($fecha);

        $year = $fecha->format("Y");
        $month = $fecha->format('m');
        $day = $fecha->format('d');

        $month = "0".$month;
        $month = substr($month, -2); 

        $fechainic = $year. "-".$month."-".$day;

        $day += 7;

        $dias_del_mes = $fecha->format("t");
        $mesSiguiente = intval($month);

        if ($day > $dias_del_mes){
            $day = ($day - $dias_del_mes);
            $mesSiguiente = intval($month) +1;

            if ($mesSiguiente == 13){
                $year = $year+1;
                $mesSiguiente = 1;
            }    
        }

        $mesSiguiente = "0".$mesSiguiente;
        $mesSiguiente = substr($mesSiguiente, -2); 

        $fechafin = $year. "-".$mesSiguiente."-".$day;
        
        $sql = "SELECT turnos.turno_fecha, turnos.turno_profesional, users.user_name, turnos.turno_categoria, turnos.turno_horas, turnos.turno_comentario FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turno_departamento = :turno_departamento AND turnos.turno_fecha between :turno_fechainic AND :turno_fechafin";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento, ':turno_fechainic' => $fechainic, ':turno_fechafin' => $fechafin));

        return $query->fetchAll();
    }

    public static function getTurno($departamento, $fecha, $categoria)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        if (Session::get("user_account_type") > 2){
            $sql = "SELECT turnos.turno_id, users.user_name, turnos.turno_categoria, turnos.turno_horas, turnos.turno_comentario FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turno_fecha = :turno_fecha AND turno_departamento = :turno_departamento AND turno_categoria = :turno_categoria";
            $query = $database->prepare($sql);
            $query->execute(array(':turno_departamento' => $departamento,':turno_fecha' => $fecha,':turno_categoria' => $categoria));
        }
        else{
            $sql = "SELECT turnos.turno_id, users.user_name, turnos.turno_categoria, turnos.turno_horas FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turno_fecha = :turno_fecha AND turno_departamento = :turno_departamento AND turno_categoria = :turno_categoria AND turnos.turno_profesional = :turno_profesional";
            $query = $database->prepare($sql);
            $query->execute(array(':turno_departamento' => $departamento,':turno_fecha' => $fecha,':turno_categoria' => $categoria, ':turno_profesional' => Session::get("user_id")));
        }
        
        return $query->fetchAll();
    }

    public static function getTurnoHoras($departamento_id, $fechauno, $fechados)
    {
        $departamento_categoria = DepartamentosModel::getDepartamento($departamento_id);

        $database = DatabaseFactory::getFactory()->getConnection();
        $resultado = "";

        $sql = "SELECT users.user_id, users.user_name, sum(turnos.turno_horas) as turno_horas FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id where turnos.turno_departamento = :turno_departamento AND turnos.turno_categoria in (1, 3) AND turnos.turno_fecha between :fechauno AND :fechados GROUP BY turno_profesional ORDER BY users.user_name;";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento_id,':fechauno' => $fechauno,':fechados' => $fechados));

        $resultado =  $query->fetchAll();

        $homologado = array();

        foreach ($resultado as $turno) {
            $homologado[$turno->user_id] = new stdClass();
            $homologado[$turno->user_id]->user_name = $turno->user_name;
            $homologado[$turno->user_id]->horas_titular = $turno->turno_horas;
            $homologado[$turno->user_id]->horas_refuerzo = 0;
        }

        if($departamento_categoria->departamento_categoria == 2){

            $sql = "SELECT users.user_id, users.user_name, sum(turnos.turno_horas) as turno_horas FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id where turnos.turno_departamento = :turno_departamento AND turnos.turno_categoria in (2, 4) AND turnos.turno_fecha between :fechauno AND :fechados GROUP BY turno_profesional;";
            $query = $database->prepare($sql);
            $query->execute(array(':turno_departamento' => $departamento_id,':fechauno' => $fechauno,':fechados' => $fechados));

            $resultado = $query->fetchAll();

            foreach ($resultado as $turno) {
                if (isset($homologado[$turno->user_id]->user_name)){
                    $homologado[$turno->user_id]->horas_refuerzo = $turno->turno_horas;
                }
                else{
                    $homologado[$turno->user_id] = new stdClass();
                    $homologado[$turno->user_id]->user_name = $turno->user_name;
                    $homologado[$turno->user_id]->horas_titular = 0;
                    $homologado[$turno->user_id]->horas_refuerzo = $turno->turno_horas;
                }
            }
        }

        $resultadoFinal = [];
        $contador = 0;

        foreach ($homologado as $user) {
            $resultadoFinal[$contador] = new stdClass();
            $resultadoFinal[$contador]->user_name = $user->user_name;
            $resultadoFinal[$contador]->horas_titular = $user->horas_titular;
            $resultadoFinal[$contador]->horas_refuerzo = $user->horas_refuerzo;
            $contador++;
        }

        return $resultadoFinal;
    }

    public static function getTurnoHorasPersonaTitular($departamento_id, $mes, $año, $user_id)
    {

        $fechainic = strval($año. "-".$mes."-01");

        $diafin = date("d",(mktime(0,0,0,intval($mes)+1,1,$año)-1));

        $fechafin = strval($año. "-".$mes."-".$diafin);

        $departamento_categoria = DepartamentosModel::getDepartamento($departamento_id);

        $database = DatabaseFactory::getFactory()->getConnection();
        $resultado = "";

        $sql = "SELECT turnos.turno_fecha, sum(turnos.turno_horas) as turno_horas, departamentos.departamento_titular ,departamentos.departamento_refuerzo FROM turnos INNER JOIN departamentos ON departamentos.departamento_id = turnos.turno_departamento WHERE turnos.turno_categoria IN (1,3) AND turnos.turno_fecha between :fechauno AND :fechados AND turnos.turno_profesional = :user_id AND turnos.turno_departamento = :turno_departamento GROUP BY turnos.turno_fecha";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento_id,':fechauno' => $fechainic,':fechados' => $fechafin, ':user_id' => $user_id));

        return $query->fetchAll();
    }

    public static function getTurnoHorasPersonaTitularFecha($departamento_id, $fecha_uno, $fecha_dos, $user_id)
    {

        $fechainic = strval($fecha_uno);
        $fechafin = strval($fecha_dos);

        $departamento_categoria = DepartamentosModel::getDepartamento($departamento_id);

        $database = DatabaseFactory::getFactory()->getConnection();
        $resultado = "";

        $sql = "SELECT turnos.turno_fecha, sum(turnos.turno_horas) as turno_horas, departamentos.departamento_titular ,departamentos.departamento_refuerzo FROM turnos INNER JOIN departamentos ON departamentos.departamento_id = turnos.turno_departamento WHERE turnos.turno_categoria IN (1,3) AND turnos.turno_fecha between :fechauno AND :fechados AND turnos.turno_profesional = :user_id AND turnos.turno_departamento = :turno_departamento GROUP BY turnos.turno_fecha";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento_id,':fechauno' => $fechainic,':fechados' => $fechafin, ':user_id' => $user_id));

        return $query->fetchAll();
    }

    public static function getTurnoHorasPersonaRefuerzo($departamento_id, $mes, $año, $user_id)
    {

        $fechainic = strval($año. "-".$mes."-01");

        $diafin = date("d",(mktime(0,0,0,intval($mes)+1,1,$año)-1));

        $fechafin = strval($año. "-".$mes."-".$diafin);

        $departamento_categoria = DepartamentosModel::getDepartamento($departamento_id);

        $database = DatabaseFactory::getFactory()->getConnection();
        $resultado = "";

        $sql = "SELECT turnos.turno_fecha, sum(turnos.turno_horas) as turno_horas, departamentos.departamento_titular ,departamentos.departamento_refuerzo FROM turnos INNER JOIN departamentos ON departamentos.departamento_id = turnos.turno_departamento WHERE turnos.turno_categoria IN (2,4) AND turnos.turno_fecha between :fechauno AND :fechados AND turnos.turno_profesional = :user_id AND turnos.turno_departamento = :turno_departamento GROUP BY turnos.turno_fecha";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento_id,':fechauno' => $fechainic,':fechados' => $fechafin, ':user_id' => $user_id));

        return $query->fetchAll();
    }

    public static function getTurnoHorasPersonaRefuerzoFecha($departamento_id, $fecha_uno, $fecha_dos, $user_id)
    {

        $fechainic = strval($fecha_uno);
        $fechafin = strval($fecha_dos);

        $departamento_categoria = DepartamentosModel::getDepartamento($departamento_id);

        $database = DatabaseFactory::getFactory()->getConnection();
        $resultado = "";

        $sql = "SELECT turnos.turno_fecha, sum(turnos.turno_horas) as turno_horas, departamentos.departamento_titular ,departamentos.departamento_refuerzo FROM turnos INNER JOIN departamentos ON departamentos.departamento_id = turnos.turno_departamento WHERE turnos.turno_categoria IN (2,4) AND turnos.turno_fecha between :fechauno AND :fechados AND turnos.turno_profesional = :user_id AND turnos.turno_departamento = :turno_departamento GROUP BY turnos.turno_fecha";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento_id,':fechauno' => $fechainic,':fechados' => $fechafin, ':user_id' => $user_id));

        return $query->fetchAll();
    }

    public static function getTurnoId($turno_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT turnos.turno_id, users.user_name, turnos.turno_categoria, turnos.turno_horas, turnos.turno_departamento, turnos.turno_fecha FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turno_id = :turno_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_id' => $turno_id));

        return $query->fetch();
    }

    public static function getTurnoInternal($turno_fecha,$turno_categoria,$turno_periodo,$turno_refuerzo,$turno_departamento)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT * FROM turnos WHERE turno_fecha = :turno_fecha AND turno_categoria = :turno_categoria AND turno_periodo = :turno_periodo AND turno_refuerzo = :turno_refuerzo AND turno_departamento = :turno_departamento LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_fecha' => $turno_fecha, ':turno_categoria' => $turno_categoria, ':turno_periodo' => $turno_periodo, ':turno_refuerzo' => $turno_refuerzo, ':turno_departamento' => $turno_departamento));

        if ($query->rowCount() == 1) {
            return true;
        }

        return false;
    }

    public static function createTurno($turno_fecha, $turno_profesional, $turno_categoria, $turno_horas, $turno_departamento)
    {

        $turno_categoria = intval($turno_categoria);

        $config_departamento = DepartamentosModel::getDepartamento($turno_departamento);

        $departamento_categoria = $config_departamento->departamento_categoria;
        $departamento_horas_realizadas = $config_departamento->departamento_horas_realizadas;
        $departamento_horas_refuerzo = $config_departamento->departamento_horas_refuerzo;

        $database = DatabaseFactory::getFactory()->getConnection();
       
        $sql = "INSERT INTO turnos (turno_fecha, turno_profesional, turno_categoria, turno_horas, turno_departamento) VALUES (:turno_fecha, :turno_profesional, :turno_categoria, :turno_horas, :turno_departamento)";
        
        $query = $database->prepare($sql);
        $query->execute(array(':turno_fecha' => $turno_fecha, ':turno_profesional' => $turno_profesional, ':turno_categoria' => $turno_categoria, ':turno_horas' => $turno_horas, ':turno_departamento' => $turno_departamento));

        $copia = Request::post("copia");
        if ($copia > 0){
            if ($turno_categoria == 0){
                if ($departamento_categoria == 0 || $copia == 1){
                    self::createTurno($turno_fecha, $turno_profesional,1,$departamento_horas_realizadas, $turno_departamento);
                }
                else {
                    if ($copia == 1 || $copia == 3){
                        self::createTurno($turno_fecha, $turno_profesional,1,$departamento_horas_realizadas, $turno_departamento);
                    }
                    if ($copia == 2 || $copia == 3){
                        self::createTurno($turno_fecha, $turno_profesional,3,$departamento_horas_realizadas, $turno_departamento);
                    }
                }
            }
            else if ($turno_categoria == 5){
                if ($copia == 1 || $copia == 3){
                    self::createTurno($turno_fecha, $turno_profesional,2,$departamento_horas_refuerzo, $turno_departamento);
                }
                if ($copia == 2 || $copia == 3){
                    self::createTurno($turno_fecha, $turno_profesional,4,$departamento_horas_refuerzo, $turno_departamento);
                }
            }
        }

        if ($query->rowCount() == 1) {
            return true;
        }

        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_CREATION_FAILED'));
        return false;
    }

    public static function updateTurno($turno_id, $turno_profesional)
    {
        if (!$turno_id || !$turno_profesional) {
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "UPDATE turnos SET turno_profesional = :turno_profesional WHERE turno_id = :turno_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_id' => $turno_id, ':turno_profesional' => $turno_profesional));

        if ($query->rowCount() == 1) {
            return true;
        }

        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_EDITING_FAILED'));
        return false;
    }

    public static function createComentario($turno_id, $fecha, $categoria, $comentario, $departamento)
    {

        $turno_id = intval($turno_id);

        if ($turno_id > 0){
            return self::updateComentario($turno_id, $comentario);
        }

        $database = DatabaseFactory::getFactory()->getConnection();
       
        $sql = "INSERT INTO turnos (turno_fecha, turno_profesional, turno_categoria, turno_horas, turno_departamento, turno_comentario) VALUES (:turno_fecha, :turno_profesional, :turno_categoria, :turno_horas, :turno_departamento, :turno_comentario)";
        
        $query = $database->prepare($sql);
        $query->execute(array(':turno_fecha' => $fecha, ':turno_profesional' => Session::get("user_id"), ':turno_comentario' => $comentario, ':turno_categoria' => $categoria, ':turno_horas' => 12, ':turno_departamento' => $departamento));

        if ($query->rowCount() == 1) {
            return true;
        }

        return false;
    }

    public static function updateComentario($turno_id, $comentario)
    {
        if (!$turno_id || !$comentario) {
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "UPDATE turnos SET turno_comentario = :turno_comentario WHERE turno_id = :turno_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_id' => $turno_id, ':turno_comentario' => $comentario));

        if ($query->rowCount() == 1) {
            return true;
        }

        return false;
    }

    public static function updateTurnoHora($turno_id, $turno_horas)
    {
        if (!$turno_id || !$turno_horas) {
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "UPDATE turnos SET turno_horas = :turno_horas WHERE turno_id = :turno_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_id' => $turno_id, ':turno_horas' => $turno_horas));

        if ($query->rowCount() == 1) {
            return true;
        }

        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_EDITING_FAILED'));
        return false;
    }

    public static function deleteTurno($turno_id)
    {
        if (!$turno_id) {
            return false;
        }

        $database = DatabaseFactory::getFactory()->getConnection();

        $prevData = self::getTurnoId($turno_id);

        $sql = "DELETE FROM turnos WHERE turno_id = :turno_id LIMIT 1";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_id' => $turno_id));

        //if ($query->rowCount() == 1) {
        //    return true;
        //}

        //return false;

        return self::getTurno($prevData->turno_departamento,$prevData->turno_fecha,$prevData->turno_categoria);

    }

    public static function valorTitularDepartamento($departamento_id)
    {

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT departamento_id, departamento_titular FROM departamentos where departamento_id = :departamento_id";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento_id));

        return $query->fetch()->departamento_titular;
    }

    public static function valorRefuerzoDepartamento($departamento_id)
    {

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT departamento_id, departamento_refuerzo FROM departamentos where departamento_id = :departamento_id";
        $query = $database->prepare($sql);
        $query->execute(array(':departamento_id' => $departamento_id));

        return $query->fetch()->departamento_refuerzo;
    }

    public static function resumenHoras($fechauno, $fechados)
    {
        if (!$fechauno || !$fechados) {
            return false;
        }

        $fechauno = strval($fechauno);
        $fechados = strval($fechados);

        $database = DatabaseFactory::getFactory()->getConnection();

        $sql = "SELECT turnos.turno_departamento, departamentos.departamento_id, departamentos.departamento_name, sum(turno_horas) as turno_horas FROM turnos INNER JOIN departamentos ON departamentos.departamento_id = turnos.turno_departamento WHERE turnos.turno_categoria IN (1,3) AND turnos.turno_fecha BETWEEN :fechauno AND :fechados group by turnos.turno_departamento;";
        $query = $database->prepare($sql);
        $query->execute(array(':fechauno' => $fechauno, ':fechados' => $fechados));

        $resultado = $query->fetchAll();

        foreach ($resultado as $turno) {
            $valorHora = self::valorTitularDepartamento($turno->departamento_id);
            $turno->turno_titular = intval($turno->turno_horas) * intval($valorHora);
        }

        $sql = "SELECT turnos.turno_departamento, departamentos.departamento_id, departamentos.departamento_name, sum(turno_horas) as turno_horas FROM turnos INNER JOIN departamentos ON departamentos.departamento_id = turnos.turno_departamento WHERE turnos.turno_categoria IN (2,4) AND turnos.turno_fecha BETWEEN :fechauno AND :fechados group by turnos.turno_departamento;";
        $query = $database->prepare($sql);
        $query->execute(array(':fechauno' => $fechauno, ':fechados' => $fechados));

        $segundo = $query->fetchAll();

        foreach ($resultado as $turno) {
            $turno->turno_refuerzo = 0;
            $turno->turno_refuerzovalor = 0;
            foreach ($segundo as $refuerzo) {
                if ($turno->turno_departamento == $refuerzo->turno_departamento){
                    $valorHora = self::valorRefuerzoDepartamento($refuerzo->departamento_id);
                    $turno->turno_refuerzo = $refuerzo->turno_horas;
                    $turno->turno_refuerzovalor = intval($refuerzo->turno_horas) * intval($valorHora);
                }
            }
        }

        return $resultado;
        
        Session::add('feedback_negative', Text::get('FEEDBACK_NOTE_EDITING_FAILED'));
        return false;
    }

    public static function simpleCalendar($departamento, $mes, $año, $semana, $medico)
    {

        $database = DatabaseFactory::getFactory()->getConnection();

        $return = new stdClass();
        $return->response = false;

        if (is_numeric($departamento) == false || is_numeric($mes) == false || is_numeric($año) == false || is_numeric($semana) == false || is_numeric($medico) == false) {
            return $return;
        }

        $departamento = intval($departamento);
        $mes = intval($mes); $año = intval($año);
        $semana = intval($semana);
        $medico = intval($medico);

        //obtener las semanas del mes solicitado
        $semanasMes = self::semanasMes($mes,$año);

        //obtener los dias de la semana solicitada
        // ej. desde el 6 hasta el 14
        //las semanas se calculan desde el 0
        $semanasMes = $semanasMes[$semana-1];

        //como el cliente necesita las semanas del lunes a domingo, incluyendo
        //dias del mes anterior o siguiente tenemos que hacer una corrección

        //primero, los dias del mes menores a 10 tiene un cero por delante en php
        if ($semanasMes["inicio"] < 10){
            $semanasMes["inicio"] = "0". $semanasMes["inicio"];
        }
        if ($semanasMes["fin"] < 10){
            $semanasMes["fin"] = "0". $semanasMes["fin"];
        }

        //segundo, hay que convertir el inicio y fin en fechas y averiguar si empiezan
        //un lunes y finalizan un domingo, de lo contrario corregir
        $semanasMes["inicio"] = new DateTime($año . '-' . $mes .'-'.$semanasMes["inicio"]);
        $semanasMes["fin"] = new DateTime($año . '-' . $mes .'-'.$semanasMes["fin"]);

        $semanasMes["inicio"] = self::retrocederDias($semanasMes["inicio"]);
        $semanasMes["fin"] = self::adelantarDias($semanasMes["fin"]);

        $return->mesAnt = 0;
        $return->mesPres = 0;
        $return->semana_ini = $semanasMes["inicio"]->format('d');
        $return->semana_fin = $semanasMes["fin"]->format('d');

        $fecha_inicial = $semanasMes["inicio"]->format('Y') . "-" . $semanasMes["inicio"]->format('m') . "-" . $semanasMes["inicio"]->format('d');
        $fecha_final = $semanasMes["fin"]->format('Y') . "-" . $semanasMes["fin"]->format('m') . "-" . $semanasMes["fin"]->format('d');
        $return->fecha_ini = $fecha_inicial;

        $sql = "SELECT turnos.turno_profesional, turnos.turno_fecha, users.user_name FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turnos.turno_departamento = :departamento AND turnos.turno_fecha BETWEEN :turno_fechain AND :turno_fechaout ";

        if ($medico == 7){
            $sql .= "AND turnos.turno_categoria IN (1, 3)  group by turnos.turno_profesional, turnos.turno_fecha ORDER BY turnos.turno_fecha";
        } else {
            $sql .= "AND turnos.turno_categoria = :turno_categoria group by turnos.turno_profesional, turnos.turno_fecha ORDER BY turnos.turno_fecha ";
        }

        $query = $database->prepare($sql);
        if ($medico == 7){
            $query->execute(array(':departamento' => $departamento, ':turno_fechain' => $fecha_inicial , ':turno_fechaout' => $fecha_final));
        } else {
            $query->execute(array(':departamento' => $departamento, ':turno_fechain' => $fecha_inicial , ':turno_fechaout' => $fecha_final, ':turno_categoria' => $medico));
        }

        $return->data = $query->fetchAll();
        return $return;

    }

    public static function getFilter($departamento, $fecha_inicial, $fecha_final)
    {
        $database = DatabaseFactory::getFactory()->getConnection();
        
        $sql = "SELECT turnos.turno_fecha, users.user_name, turnos.turno_categoria, turnos.turno_horas, turnos.turno_comentario FROM turnos INNER JOIN users ON turnos.turno_profesional = users.user_id WHERE turno_departamento = :turno_departamento AND turnos.turno_fecha between :turno_fechainic AND :turno_fechafin";
        $query = $database->prepare($sql);
        $query->execute(array(':turno_departamento' => $departamento, ':turno_fechainic' => $fecha_inicial, ':turno_fechafin' => $fecha_final));

        return $query->fetchAll();
    }

    public static function validateMonth($month)
    {
        $month = ($month > 12) ? 12 : $month;
        $month = ($month < 1) ? 1 : $month;
        return  $month;
    }

    public static function getMonthDaysFromMonth($año,$mes)
    {
        $fecha = new DateTime($año . '-' . $mes .'-01');
        return $fecha->format('t');
    }

    public static function dateForMySQL($day)
    {
        $day = "0".$day;
        return substr($day, -2); 
    }

    //obtener el último día del mes de la fecha actual
    public static function _data_last_month_day() 
    {
        $month = date('m');
        $year = date('Y');
        $day = date("d", mktime(0,0,0, $month+1, 0, $year));

        return date('Y-m-d', mktime(0,0,0, $month, $day, $year));
    }

    //obtener el primer día de la fecha actual
    public static function _data_first_month_day() 
    {
        $month = date('m');
        $year = date('Y');
        return date('Y-m-d', mktime(0,0,0, $month, 1, $year));
    }

    //function que calcula las semanas de un mes
    //devuelve un arreglo con las semanas del mes
    //y desde que dia hasta que dia termina
    public static function semanasMes($mes,$anno)
	{		
		$ultimo_dia = date("d",mktime(0,0,0,$mes+1,0,$anno));
		$semanas = array();
		$cantidad_semanas = 0;
		$inicio = 1;
		$fin = 0;
		$dia_semana = '';
		for($i = 1;$i<=$ultimo_dia;$i++)
		{
			$fecha = mktime(0,0,0,$mes,$i,$anno);
			$dia_semana = date('w',($fecha));
			if($dia_semana == 0)
			{
				$semanas[$cantidad_semanas] = array('inicio' => $inicio,'fin'=>$i);
				$inicio = $i+1;
				$cantidad_semanas++;
			}
		}
		$ultima_semana = end($semanas);
		if($ultima_semana['fin'] != $ultimo_dia)
		{
			$semanas[$cantidad_semanas] = array('inicio' => $inicio,'fin' => $ultimo_dia);
		}
		return $semanas;
    }
    
    //retrocede una fecha hasta que el día coincida con un lunes
    public static function retrocederDias($fecha)
    {
        while ($fecha->format('N') != 1) {
            //convertir la fecha en timestamp
            $timestamp = strtotime($fecha->format('Y') . "-" . $fecha->format('m') . "-" . $fecha->format('d'));
            //reiniciar la fecha y hora para que la fecha timestamp empiece en el inicio del día
            $beginOfDay  = strtotime("today", $timestamp);
            //retroceder un día
            $yesterday  = strtotime("yesterday", $beginOfDay);
            
            $return = new DateTime();
            $return->setTimestamp($yesterday);
            
            $fecha = $return;
        }
        return $fecha; 
    }

    //adelanta una fecha hasta que el día coincida con un domingo
    public static function adelantarDias($fecha)
    {
        while ($fecha->format('N') != 7) {
            //convertir la fecha en timestamp
            $timestamp = strtotime($fecha->format('Y') . "-" . $fecha->format('m') . "-" . $fecha->format('d'));
            //reiniciar la fecha y hora para que la fecha timestamp empiece en el inicio del día
            $beginOfDay  = strtotime("today", $timestamp);
            //adelantar un día
            $tomorrow  = strtotime("tomorrow", $beginOfDay);
                
            $return = new DateTime();
            $return->setTimestamp($tomorrow);
                
            $fecha = $return;
        }
        return $fecha; 
    }
}