<?php

class ApiModel
{
    public static function validKey($key)
    {
        $database = DatabaseFactory::getFactory()->getConnection();
        $sql = "SELECT session_id FROM users WHERE session_id = :session_id LIMIT 1";

        $query = $database->prepare($sql);
        $query->execute(array(":session_id" => $key));

        $result = $query->fetch();
        $userSessionId = !empty($result)? true: false;
        return $userSessionId;
    }
}